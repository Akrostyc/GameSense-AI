"""
Processador de vídeos de gameplay.
Este módulo implementa funções para processar vídeos de gameplay e extrair informações relevantes.
"""

import os
import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

class GameplayVideoProcessor:
    """
    Processador de vídeos de gameplay.
    
    Esta classe implementa métodos para processar vídeos de gameplay e extrair informações relevantes.
    """
    
    def __init__(self, video_path, game_type, output_dir):
        """
        Inicializa o processador de vídeo.
        
        Args:
            video_path (str): Caminho para o arquivo de vídeo
            game_type (str): Tipo de jogo ('rocket_league' ou 'rainbow_six')
            output_dir (str): Diretório para salvar os resultados
        """
        self.video_path = video_path
        self.game_type = game_type
        self.output_dir = output_dir
        self.cap = None
        self.fps = 0
        self.frame_count = 0
        self.width = 0
        self.height = 0
        self.duration = 0
        self.frames = []
        self.analysis_results = {}
        
        # Criar diretório de saída se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        # Abrir vídeo
        self.cap = cv2.VideoCapture(video_path)
        
        # Verificar se o vídeo foi aberto corretamente
        if not self.cap.isOpened():
            # Tentar novamente com opções diferentes
            self.cap = cv2.VideoCapture(video_path, cv2.CAP_FFMPEG)
            
            if not self.cap.isOpened():
                raise ValueError(f"Não foi possível abrir o vídeo: {video_path}")
        
        # Obter informações do vídeo
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        # Calcular duração em segundos
        if self.fps > 0:
            self.duration = self.frame_count / self.fps
    
    def __del__(self):
        """
        Destrutor para liberar recursos.
        """
        if self.cap is not None:
            self.cap.release()
    
    def extract_frames(self, sample_rate=1):
        """
        Extrai frames do vídeo.
        
        Args:
            sample_rate (int): Taxa de amostragem (1 = todos os frames, 2 = um a cada 2 frames, etc.)
            
        Returns:
            list: Lista de frames extraídos
        """
        frames = []
        frame_index = 0
        
        # Reiniciar vídeo
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        
        # Extrair frames
        while True:
            ret, frame = self.cap.read()
            
            if not ret:
                break
            
            if frame_index % sample_rate == 0:
                frames.append(frame)
            
            frame_index += 1
        
        self.frames = frames
        return frames
    
    def analyze_video(self):
        """
        Analisa o vídeo e extrai informações relevantes.
        
        Returns:
            dict: Resultados da análise
        """
        # Extrair frames se ainda não foram extraídos
        if not self.frames:
            self.extract_frames(sample_rate=30)  # 1 frame por segundo para vídeo de 30 fps
        
        # Inicializar resultados
        results = {
            "video_info": {
                "path": self.video_path,
                "fps": self.fps,
                "frame_count": self.frame_count,
                "width": self.width,
                "height": self.height,
                "duration": self.duration
            },
            "game_type": self.game_type,
            "analysis": {}
        }
        
        # Análise específica para cada tipo de jogo
        if self.game_type == "rocket_league":
            results["analysis"] = self._analyze_rocket_league()
        elif self.game_type == "rainbow_six":
            results["analysis"] = self._analyze_rainbow_six()
        else:
            results["analysis"] = self._analyze_generic()
        
        self.analysis_results = results
        return results
    
    def _analyze_rocket_league(self):
        """
        Analisa vídeo de Rocket League.
        
        Returns:
            dict: Resultados da análise
        """
        # Implementação simulada para demonstração
        # Em uma implementação real, aqui seriam aplicados algoritmos de visão computacional
        # para detectar jogadores, bola, boost, etc.
        
        analysis = {
            "detected_objects": {
                "players": self._simulate_player_detection(),
                "ball": self._simulate_ball_detection(),
                "boost_pads": self._simulate_boost_detection()
            },
            "events": self._simulate_event_detection(),
            "metrics": {
                "player_possession": {
                    "blue_team": 45,  # Porcentagem
                    "orange_team": 55
                },
                "field_control": {
                    "blue_team": 48,  # Porcentagem
                    "orange_team": 52
                },
                "boost_usage": {
                    "blue_team": 65,  # Porcentagem média de uso
                    "orange_team": 70
                }
            }
        }
        
        return analysis
    
    def _analyze_rainbow_six(self):
        """
        Analisa vídeo de Rainbow Six Siege.
        
        Returns:
            dict: Resultados da análise
        """
        # Implementação simulada para demonstração
        # Em uma implementação real, aqui seriam aplicados algoritmos de visão computacional
        # para detectar jogadores, armas, objetivos, etc.
        
        analysis = {
            "detected_objects": {
                "players": self._simulate_r6_player_detection(),
                "objectives": self._simulate_r6_objective_detection()
            },
            "events": self._simulate_r6_event_detection(),
            "metrics": {
                "attacker_advantage": 0.8,  # Índice de vantagem (>1 = atacantes, <1 = defensores)
                "site_control": {
                    "attackers": 40,  # Porcentagem
                    "defenders": 60
                },
                "operator_usage": {
                    "most_effective": "Ash",
                    "least_effective": "Glaz"
                }
            }
        }
        
        return analysis
    
    def _analyze_generic(self):
        """
        Analisa vídeo genérico.
        
        Returns:
            dict: Resultados da análise
        """
        # Análise básica para qualquer tipo de vídeo
        
        # Calcular histograma de cores
        histograms = []
        for i, frame in enumerate(self.frames):
            if i % 10 == 0:  # Analisar um a cada 10 frames
                hist = self._calculate_color_histogram(frame)
                histograms.append(hist)
        
        # Calcular movimento entre frames
        motion = []
        for i in range(1, len(self.frames)):
            if i % 10 == 0:  # Analisar um a cada 10 frames
                prev_frame = self.frames[i-1]
                curr_frame = self.frames[i]
                motion_value = self._calculate_motion(prev_frame, curr_frame)
                motion.append(motion_value)
        
        analysis = {
            "color_distribution": {
                "average_histogram": np.mean(histograms, axis=0).tolist() if histograms else []
            },
            "motion_analysis": {
                "average_motion": np.mean(motion) if motion else 0,
                "max_motion": np.max(motion) if motion else 0
            },
            "scene_changes": self._detect_scene_changes()
        }
        
        return analysis
    
    def _calculate_color_histogram(self, frame):
        """
        Calcula histograma de cores de um frame.
        
        Args:
            frame (numpy.ndarray): Frame do vídeo
            
        Returns:
            list: Histograma de cores
        """
        # Converter para HSV
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # Calcular histograma
        hist = cv2.calcHist([hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
        
        # Normalizar
        cv2.normalize(hist, hist, 0, 1, cv2.NORM_MINMAX)
        
        return hist.flatten().tolist()
    
    def _calculate_motion(self, prev_frame, curr_frame):
        """
        Calcula movimento entre dois frames.
        
        Args:
            prev_frame (numpy.ndarray): Frame anterior
            curr_frame (numpy.ndarray): Frame atual
            
        Returns:
            float: Valor de movimento
        """
        # Converter para escala de cinza
        prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
        curr_gray = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
        
        # Calcular fluxo óptico
        flow = cv2.calcOpticalFlowFarneback(prev_gray, curr_gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        
        # Calcular magnitude
        mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
        
        # Retornar média da magnitude
        return np.mean(mag)
    
    def _detect_scene_changes(self):
        """
        Detecta mudanças de cena no vídeo.
        
        Returns:
            list: Lista de frames onde ocorrem mudanças de cena
        """
        # Implementação simulada
        # Em uma implementação real, aqui seria aplicado um algoritmo de detecção de mudanças de cena
        
        # Simular algumas mudanças de cena
        scene_changes = []
        for i in range(5):
            frame_index = int(i * self.frame_count / 5)
            scene_changes.append({
                "frame": frame_index,
                "time": frame_index / self.fps if self.fps > 0 else 0
            })
        
        return scene_changes
    
    def _simulate_player_detection(self):
        """
        Simula detecção de jogadores em Rocket League.
        
        Returns:
            list: Lista de jogadores detectados
        """
        # Simular detecção de 6 jogadores (3 por time)
        players = []
        
        for i in range(6):
            team = 0 if i < 3 else 1  # 0 = blue, 1 = orange
            
            player = {
                "id": f"player{i+1}",
                "team": team,
                "positions": []
            }
            
            # Simular posições ao longo do tempo
            for j in range(len(self.frames)):
                if j % 10 == 0:  # Um a cada 10 frames
                    # Simular movimento circular com ruído
                    angle = j / 10 + i
                    radius = 100 + 20 * i
                    
                    if team == 0:  # Time azul
                        center_x = self.width / 4
                    else:  # Time laranja
                        center_x = 3 * self.width / 4
                    
                    center_y = self.height / 2
                    
                    x = center_x + radius * np.cos(angle / 10)
                    y = center_y + radius * np.sin(angle / 10)
                    
                    # Adicionar ruído
                    x += np.random.normal(0, 10)
                    y += np.random.normal(0, 10)
                    
                    player["positions"].append({
                        "frame": j,
                        "time": j / self.fps if self.fps > 0 else 0,
                        "x": int(x),
                        "y": int(y)
                    })
            
            players.append(player)
        
        return players
    
    def _simulate_ball_detection(self):
        """
        Simula detecção da bola em Rocket League.
        
        Returns:
            dict: Informações da bola detectada
        """
        # Simular posições da bola ao longo do tempo
        positions = []
        
        for j in range(len(self.frames)):
            if j % 10 == 0:  # Um a cada 10 frames
                # Simular movimento da bola
                angle = j / 5
                radius = 150
                
                center_x = self.width / 2
                center_y = self.height / 2
                
                x = center_x + radius * np.cos(angle / 10)
                y = center_y + radius * np.sin(angle / 10)
                z = 50 + 30 * np.sin(angle / 5)  # Altura simulada
                
                # Adicionar ruído
                x += np.random.normal(0, 5)
                y += np.random.normal(0, 5)
                z += np.random.normal(0, 2)
                
                positions.append({
                    "frame": j,
                    "time": j / self.fps if self.fps > 0 else 0,
                    "x": int(x),
                    "y": int(y),
                    "z": int(z)
                })
        
        return {
            "positions": positions
        }
    
    def _simulate_boost_detection(self):
        """
        Simula detecção de boost pads em Rocket League.
        
        Returns:
            list: Lista de boost pads detectados
        """
        # Simular detecção de 6 boost pads
        boost_pads = []
        
        for i in range(6):
            # Distribuir boost pads pelo campo
            angle = i * np.pi / 3
            radius = 200
            
            center_x = self.width / 2
            center_y = self.height / 2
            
            x = center_x + radius * np.cos(angle)
            y = center_y + radius * np.sin(angle)
            
            boost_pads.append({
                "id": f"boost{i+1}",
                "x": int(x),
                "y": int(y),
                "type": "large" if i % 2 == 0 else "small"
            })
        
        return boost_pads
    
    def _simulate_event_detection(self):
        """
        Simula detecção de eventos em Rocket League.
        
        Returns:
            list: Lista de eventos detectados
        """
        # Simular alguns eventos
        events = []
        
        # Simular gols
        events.append({
            "type": "goal",
            "team": 0,  # Time azul
            "player": "player2",
            "frame": int(self.frame_count * 0.2),
            "time": self.frame_count * 0.2 / self.fps if self.fps > 0 else 0
        })
        
        events.append({
            "type": "goal",
            "team": 1,  # Time laranja
            "player": "player5",
            "frame": int(self.frame_count * 0.6),
            "time": self.frame_count * 0.6 / self.fps if self.fps > 0 else 0
        })
        
        # Simular saves
        events.append({
            "type": "save",
            "player": "player1",
            "frame": int(self.frame_count * 0.4),
            "time": self.frame_count * 0.4 / self.fps if self.fps > 0 else 0
        })
        
        # Simular demolitions
        events.append({
            "type": "demolition",
            "attacker": "player6",
            "victim": "player3",
            "frame": int(self.frame_count * 0.8),
            "time": self.frame_count * 0.8 / self.fps if self.fps > 0 else 0
        })
        
        return events
    
    def _simulate_r6_player_detection(self):
        """
        Simula detecção de jogadores em Rainbow Six Siege.
        
        Returns:
            list: Lista de jogadores detectados
        """
        # Simular detecção de 10 jogadores (5 por time)
        players = []
        
        for i in range(10):
            team = "attackers" if i < 5 else "defenders"
            
            # Definir operadores
            attackers = ["Ash", "Thermite", "Thatcher", "Sledge", "IQ"]
            defenders = ["Jager", "Bandit", "Mute", "Rook", "Doc"]
            
            operator = attackers[i] if i < 5 else defenders[i-5]
            
            player = {
                "id": f"player{i+1}",
                "team": team,
                "operator": operator,
                "positions": []
            }
            
            # Simular posições ao longo do tempo
            for j in range(len(self.frames)):
                if j % 10 == 0:  # Um a cada 10 frames
                    # Simular movimento com ruído
                    if team == "attackers":
                        # Atacantes se movem de fora para dentro
                        progress = min(1.0, j / (len(self.frames) * 0.8))
                        center_x = self.width * (0.2 + 0.3 * progress)
                        center_y = self.height * (0.2 + 0.3 * progress)
                    else:
                        # Defensores ficam mais próximos do objetivo
                        center_x = self.width * 0.7
                        center_y = self.height * 0.7
                    
                    # Adicionar variação por jogador
                    angle = j / 10 + i
                    radius = 50 + 10 * i
                    
                    x = center_x + radius * np.cos(angle / 10)
                    y = center_y + radius * np.sin(angle / 10)
                    
                    # Adicionar ruído
                    x += np.random.normal(0, 15)
                    y += np.random.normal(0, 15)
                    
                    player["positions"].append({
                        "frame": j,
                        "time": j / self.fps if self.fps > 0 else 0,
                        "x": int(x),
                        "y": int(y)
                    })
            
            players.append(player)
        
        return players
    
    def _simulate_r6_objective_detection(self):
        """
        Simula detecção de objetivos em Rainbow Six Siege.
        
        Returns:
            list: Lista de objetivos detectados
        """
        # Simular detecção de 2 bombas
        objectives = []
        
        # Bomba A
        objectives.append({
            "id": "bomb_a",
            "type": "bomb",
            "x": int(self.width * 0.7),
            "y": int(self.height * 0.6)
        })
        
        # Bomba B
        objectives.append({
            "id": "bomb_b",
            "type": "bomb",
            "x": int(self.width * 0.8),
            "y": int(self.height * 0.7)
        })
        
        return objectives
    
    def _simulate_r6_event_detection(self):
        """
        Simula detecção de eventos em Rainbow Six Siege.
        
        Returns:
            list: Lista de eventos detectados
        """
        # Simular alguns eventos
        events = []
        
        # Simular eliminações
        events.append({
            "type": "kill",
            "attacker": "player1",
            "victim": "player6",
            "weapon": "R4-C",
            "headshot": True,
            "frame": int(self.frame_count * 0.3),
            "time": self.frame_count * 0.3 / self.fps if self.fps > 0 else 0
        })
        
        events.append({
            "type": "kill",
            "attacker": "player7",
            "victim": "player2",
            "weapon": "MP7",
            "headshot": False,
            "frame": int(self.frame_count * 0.4),
            "time": self.frame_count * 0.4 / self.fps if self.fps > 0 else 0
        })
        
        # Simular plant/defuse
        events.append({
            "type": "bomb_plant",
            "player": "player3",
            "site": "bomb_a",
            "frame": int(self.frame_count * 0.6),
            "time": self.frame_count * 0.6 / self.fps if self.fps > 0 else 0
        })
        
        events.append({
            "type": "bomb_defuse",
            "player": "player8",
            "site": "bomb_a",
            "frame": int(self.frame_count * 0.8),
            "time": self.frame_count * 0.8 / self.fps if self.fps > 0 else 0
        })
        
        return events
    
    def generate_visualizations(self):
        """
        Gera visualizações dos resultados da análise.
        
        Returns:
            dict: Caminhos para os arquivos de visualização
        """
        # Verificar se a análise foi realizada
        if not self.analysis_results:
            self.analyze_video()
        
        visualizations = {}
        
        # Gerar visualizações específicas para cada tipo de jogo
        if self.game_type == "rocket_league":
            visualizations = self._generate_rocket_league_visualizations()
        elif self.game_type == "rainbow_six":
            visualizations = self._generate_rainbow_six_visualizations()
        else:
            visualizations = self._generate_generic_visualizations()
        
        return visualizations
    
    def _generate_rocket_league_visualizations(self):
        """
        Gera visualizações para análise de Rocket League.
        
        Returns:
            dict: Caminhos para os arquivos de visualização
        """
        visualizations = {}
        
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        players = analysis.get("detected_objects", {}).get("players", [])
        ball = analysis.get("detected_objects", {}).get("ball", {}).get("positions", [])
        
        # Visualização de posições dos jogadores
        player_positions_path = os.path.join(self.output_dir, "player_positions.png")
        self._plot_player_positions(players, player_positions_path)
        visualizations["player_positions"] = player_positions_path
        
        # Visualização da trajetória da bola
        ball_trajectory_path = os.path.join(self.output_dir, "ball_trajectory.png")
        self._plot_ball_trajectory(ball, ball_trajectory_path)
        visualizations["ball_trajectory"] = ball_trajectory_path
        
        # Visualização de métricas
        metrics_path = os.path.join(self.output_dir, "metrics.png")
        self._plot_rocket_league_metrics(analysis.get("metrics", {}), metrics_path)
        visualizations["metrics"] = metrics_path
        
        # Capturar frame com anotações
        annotated_frame_path = os.path.join(self.output_dir, "annotated_frame.png")
        self._create_annotated_frame(annotated_frame_path)
        visualizations["annotated_frame"] = annotated_frame_path
        
        return visualizations
    
    def _generate_rainbow_six_visualizations(self):
        """
        Gera visualizações para análise de Rainbow Six Siege.
        
        Returns:
            dict: Caminhos para os arquivos de visualização
        """
        visualizations = {}
        
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        players = analysis.get("detected_objects", {}).get("players", [])
        objectives = analysis.get("detected_objects", {}).get("objectives", [])
        
        # Visualização de posições dos jogadores
        player_positions_path = os.path.join(self.output_dir, "player_positions.png")
        self._plot_r6_player_positions(players, objectives, player_positions_path)
        visualizations["player_positions"] = player_positions_path
        
        # Visualização de eventos
        events_path = os.path.join(self.output_dir, "events.png")
        self._plot_r6_events(analysis.get("events", []), events_path)
        visualizations["events"] = events_path
        
        # Visualização de métricas
        metrics_path = os.path.join(self.output_dir, "metrics.png")
        self._plot_rainbow_six_metrics(analysis.get("metrics", {}), metrics_path)
        visualizations["metrics"] = metrics_path
        
        # Capturar frame com anotações
        annotated_frame_path = os.path.join(self.output_dir, "annotated_frame.png")
        self._create_annotated_frame(annotated_frame_path)
        visualizations["annotated_frame"] = annotated_frame_path
        
        return visualizations
    
    def _generate_generic_visualizations(self):
        """
        Gera visualizações para análise genérica.
        
        Returns:
            dict: Caminhos para os arquivos de visualização
        """
        visualizations = {}
        
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        
        # Visualização de histograma de cores
        color_hist_path = os.path.join(self.output_dir, "color_histogram.png")
        self._plot_color_histogram(analysis.get("color_distribution", {}).get("average_histogram", []), color_hist_path)
        visualizations["color_histogram"] = color_hist_path
        
        # Visualização de movimento
        motion_path = os.path.join(self.output_dir, "motion.png")
        self._plot_motion(analysis.get("motion_analysis", {}), motion_path)
        visualizations["motion"] = motion_path
        
        # Capturar frames representativos
        frames_path = os.path.join(self.output_dir, "representative_frames.png")
        self._plot_representative_frames(frames_path)
        visualizations["representative_frames"] = frames_path
        
        return visualizations
    
    def _plot_player_positions(self, players, output_path):
        """
        Plota posições dos jogadores em Rocket League.
        
        Args:
            players (list): Lista de jogadores
            output_path (str): Caminho para salvar a imagem
        """
        plt.figure(figsize=(10, 8))
        
        # Simular campo de Rocket League
        plt.plot([0, self.width, self.width, 0, 0], [0, 0, self.height, self.height, 0], 'k-', linewidth=2)
        plt.plot([self.width/2, self.width/2], [0, self.height], 'k--', linewidth=1)
        
        # Plotar posições dos jogadores
        for player in players:
            team = player["team"]
            positions = player["positions"]
            
            if not positions:
                continue
            
            x = [pos["x"] for pos in positions]
            y = [pos["y"] for pos in positions]
            
            if team == 0:  # Time azul
                color = 'blue'
            else:  # Time laranja
                color = 'orange'
            
            plt.plot(x, y, color=color, alpha=0.7, label=f"Player {player['id']}")
        
        # Configurar gráfico
        plt.title("Posições dos Jogadores")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.grid(True)
        
        # Remover legendas duplicadas
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), loc='upper right')
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_ball_trajectory(self, ball_positions, output_path):
        """
        Plota trajetória da bola em Rocket League.
        
        Args:
            ball_positions (list): Lista de posições da bola
            output_path (str): Caminho para salvar a imagem
        """
        if not ball_positions:
            # Criar imagem vazia
            plt.figure(figsize=(10, 8))
            plt.title("Trajetória da Bola (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        plt.figure(figsize=(10, 8))
        
        # Simular campo de Rocket League
        plt.plot([0, self.width, self.width, 0, 0], [0, 0, self.height, self.height, 0], 'k-', linewidth=2)
        plt.plot([self.width/2, self.width/2], [0, self.height], 'k--', linewidth=1)
        
        # Extrair posições
        x = [pos["x"] for pos in ball_positions]
        y = [pos["y"] for pos in ball_positions]
        times = [pos["time"] for pos in ball_positions]
        
        # Plotar trajetória com gradiente de cores baseado no tempo
        plt.scatter(x, y, c=times, cmap='viridis', s=30, alpha=0.7)
        
        # Adicionar linha conectando os pontos
        plt.plot(x, y, 'k-', alpha=0.3)
        
        # Adicionar barra de cores
        cbar = plt.colorbar()
        cbar.set_label("Tempo (s)")
        
        # Configurar gráfico
        plt.title("Trajetória da Bola")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.grid(True)
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_rocket_league_metrics(self, metrics, output_path):
        """
        Plota métricas de Rocket League.
        
        Args:
            metrics (dict): Métricas da análise
            output_path (str): Caminho para salvar a imagem
        """
        if not metrics:
            # Criar imagem vazia
            plt.figure(figsize=(10, 8))
            plt.title("Métricas (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        # Extrair métricas
        possession = metrics.get("player_possession", {})
        field_control = metrics.get("field_control", {})
        boost_usage = metrics.get("boost_usage", {})
        
        # Criar figura com subplots
        fig, axs = plt.subplots(3, 1, figsize=(10, 12))
        
        # Posse de bola
        possession_data = [possession.get("blue_team", 0), possession.get("orange_team", 0)]
        axs[0].bar(["Time Azul", "Time Laranja"], possession_data, color=['blue', 'orange'])
        axs[0].set_title("Posse de Bola (%)")
        axs[0].set_ylim(0, 100)
        
        # Controle de campo
        field_data = [field_control.get("blue_team", 0), field_control.get("orange_team", 0)]
        axs[1].bar(["Time Azul", "Time Laranja"], field_data, color=['blue', 'orange'])
        axs[1].set_title("Controle de Campo (%)")
        axs[1].set_ylim(0, 100)
        
        # Uso de boost
        boost_data = [boost_usage.get("blue_team", 0), boost_usage.get("orange_team", 0)]
        axs[2].bar(["Time Azul", "Time Laranja"], boost_data, color=['blue', 'orange'])
        axs[2].set_title("Uso Médio de Boost (%)")
        axs[2].set_ylim(0, 100)
        
        # Ajustar layout
        plt.tight_layout()
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_r6_player_positions(self, players, objectives, output_path):
        """
        Plota posições dos jogadores em Rainbow Six Siege.
        
        Args:
            players (list): Lista de jogadores
            objectives (list): Lista de objetivos
            output_path (str): Caminho para salvar a imagem
        """
        plt.figure(figsize=(10, 8))
        
        # Simular mapa de Rainbow Six
        plt.plot([0, self.width, self.width, 0, 0], [0, 0, self.height, self.height, 0], 'k-', linewidth=2)
        
        # Plotar objetivos
        for obj in objectives:
            plt.plot(obj["x"], obj["y"], 'rs', markersize=10, label=f"{obj['id']} ({obj['type']})")
        
        # Plotar posições dos jogadores
        for player in players:
            team = player["team"]
            positions = player["positions"]
            
            if not positions:
                continue
            
            x = [pos["x"] for pos in positions]
            y = [pos["y"] for pos in positions]
            
            if team == "attackers":
                color = 'blue'
            else:  # defenders
                color = 'orange'
            
            plt.plot(x, y, color=color, alpha=0.7, label=f"{player['operator']} ({player['id']})")
        
        # Configurar gráfico
        plt.title("Posições dos Jogadores e Objetivos")
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.grid(True)
        
        # Remover legendas duplicadas
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), loc='upper right')
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_r6_events(self, events, output_path):
        """
        Plota eventos de Rainbow Six Siege.
        
        Args:
            events (list): Lista de eventos
            output_path (str): Caminho para salvar a imagem
        """
        if not events:
            # Criar imagem vazia
            plt.figure(figsize=(10, 8))
            plt.title("Eventos (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        plt.figure(figsize=(12, 6))
        
        # Extrair tipos de eventos e tempos
        event_types = []
        event_times = []
        event_colors = []
        
        for event in events:
            event_type = event["type"]
            event_time = event["time"]
            
            event_types.append(event_type)
            event_times.append(event_time)
            
            if event_type == "kill":
                color = 'red'
            elif event_type == "bomb_plant":
                color = 'green'
            elif event_type == "bomb_defuse":
                color = 'blue'
            else:
                color = 'gray'
            
            event_colors.append(color)
        
        # Plotar eventos na linha do tempo
        plt.scatter(event_times, [1] * len(event_times), c=event_colors, s=100)
        
        # Adicionar anotações
        for i, (event_type, event_time) in enumerate(zip(event_types, event_times)):
            plt.annotate(event_type, (event_time, 1), xytext=(0, 10), 
                         textcoords='offset points', ha='center', va='bottom',
                         rotation=45)
        
        # Configurar gráfico
        plt.title("Linha do Tempo de Eventos")
        plt.xlabel("Tempo (s)")
        plt.yticks([])  # Remover eixo Y
        plt.grid(True, axis='x')
        
        # Ajustar limites
        if event_times:
            plt.xlim(0, max(event_times) * 1.1)
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_rainbow_six_metrics(self, metrics, output_path):
        """
        Plota métricas de Rainbow Six Siege.
        
        Args:
            metrics (dict): Métricas da análise
            output_path (str): Caminho para salvar a imagem
        """
        if not metrics:
            # Criar imagem vazia
            plt.figure(figsize=(10, 8))
            plt.title("Métricas (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        # Extrair métricas
        attacker_advantage = metrics.get("attacker_advantage", 0)
        site_control = metrics.get("site_control", {})
        operator_usage = metrics.get("operator_usage", {})
        
        # Criar figura com subplots
        fig, axs = plt.subplots(2, 1, figsize=(10, 10))
        
        # Vantagem dos atacantes
        advantage_data = [max(0, attacker_advantage), max(0, 1 - attacker_advantage)]
        axs[0].bar(["Atacantes", "Defensores"], advantage_data, color=['blue', 'orange'])
        axs[0].set_title("Índice de Vantagem")
        axs[0].set_ylim(0, 1)
        
        # Controle do site
        site_data = [site_control.get("attackers", 0), site_control.get("defenders", 0)]
        axs[1].bar(["Atacantes", "Defensores"], site_data, color=['blue', 'orange'])
        axs[1].set_title("Controle do Site (%)")
        axs[1].set_ylim(0, 100)
        
        # Adicionar informações de operadores
        most_effective = operator_usage.get("most_effective", "N/A")
        least_effective = operator_usage.get("least_effective", "N/A")
        
        plt.figtext(0.5, 0.01, f"Operador mais efetivo: {most_effective} | Operador menos efetivo: {least_effective}",
                   ha="center", fontsize=12, bbox={"facecolor":"lightgray", "alpha":0.5, "pad":5})
        
        # Ajustar layout
        plt.tight_layout(rect=[0, 0.05, 1, 1])
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_color_histogram(self, histogram, output_path):
        """
        Plota histograma de cores.
        
        Args:
            histogram (list): Histograma de cores
            output_path (str): Caminho para salvar a imagem
        """
        if not histogram:
            # Criar imagem vazia
            plt.figure(figsize=(10, 6))
            plt.title("Histograma de Cores (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        plt.figure(figsize=(10, 6))
        
        # Plotar histograma
        plt.bar(range(len(histogram)), histogram)
        
        # Configurar gráfico
        plt.title("Distribuição de Cores")
        plt.xlabel("Bin")
        plt.ylabel("Frequência Normalizada")
        plt.grid(True)
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_motion(self, motion_analysis, output_path):
        """
        Plota análise de movimento.
        
        Args:
            motion_analysis (dict): Análise de movimento
            output_path (str): Caminho para salvar a imagem
        """
        if not motion_analysis:
            # Criar imagem vazia
            plt.figure(figsize=(10, 6))
            plt.title("Análise de Movimento (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        plt.figure(figsize=(10, 6))
        
        # Extrair métricas
        avg_motion = motion_analysis.get("average_motion", 0)
        max_motion = motion_analysis.get("max_motion", 0)
        
        # Plotar barras
        plt.bar(["Movimento Médio", "Movimento Máximo"], [avg_motion, max_motion])
        
        # Configurar gráfico
        plt.title("Análise de Movimento")
        plt.ylabel("Magnitude")
        plt.grid(True)
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _plot_representative_frames(self, output_path):
        """
        Plota frames representativos do vídeo.
        
        Args:
            output_path (str): Caminho para salvar a imagem
        """
        if not self.frames:
            # Criar imagem vazia
            plt.figure(figsize=(12, 8))
            plt.title("Frames Representativos (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        # Selecionar frames representativos
        num_frames = min(4, len(self.frames))
        indices = [int(i * len(self.frames) / num_frames) for i in range(num_frames)]
        
        # Criar figura com subplots
        fig, axs = plt.subplots(2, 2, figsize=(12, 8))
        axs = axs.flatten()
        
        # Plotar frames
        for i, idx in enumerate(indices):
            if i < len(axs):
                frame = self.frames[idx]
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                axs[i].imshow(frame_rgb)
                axs[i].set_title(f"Frame {idx} (Tempo: {idx/self.fps:.2f}s)")
                axs[i].axis('off')
        
        # Ajustar layout
        plt.tight_layout()
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _create_annotated_frame(self, output_path):
        """
        Cria um frame com anotações.
        
        Args:
            output_path (str): Caminho para salvar a imagem
        """
        if not self.frames:
            # Criar imagem vazia
            plt.figure(figsize=(10, 8))
            plt.title("Frame Anotado (Dados não disponíveis)")
            plt.savefig(output_path)
            plt.close()
            return
        
        # Selecionar um frame do meio do vídeo
        middle_idx = len(self.frames) // 2
        frame = self.frames[middle_idx].copy()
        
        # Adicionar anotações específicas para cada tipo de jogo
        if self.game_type == "rocket_league":
            self._annotate_rocket_league_frame(frame)
        elif self.game_type == "rainbow_six":
            self._annotate_rainbow_six_frame(frame)
        else:
            self._annotate_generic_frame(frame)
        
        # Converter para RGB para matplotlib
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Plotar frame
        plt.figure(figsize=(12, 8))
        plt.imshow(frame_rgb)
        plt.title(f"Frame Anotado (Tempo: {middle_idx/self.fps:.2f}s)")
        plt.axis('off')
        
        # Salvar figura
        plt.savefig(output_path)
        plt.close()
    
    def _annotate_rocket_league_frame(self, frame):
        """
        Adiciona anotações a um frame de Rocket League.
        
        Args:
            frame (numpy.ndarray): Frame a ser anotado
        """
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        players = analysis.get("detected_objects", {}).get("players", [])
        ball = analysis.get("detected_objects", {}).get("ball", {}).get("positions", [])
        
        # Selecionar posições para o frame atual
        middle_idx = len(self.frames) // 2
        middle_time = middle_idx / self.fps if self.fps > 0 else 0
        
        # Anotar jogadores
        for player in players:
            # Encontrar posição mais próxima do tempo atual
            positions = player["positions"]
            if not positions:
                continue
            
            closest_pos = min(positions, key=lambda pos: abs(pos["time"] - middle_time))
            
            # Definir cor com base no time
            if player["team"] == 0:  # Time azul
                color = (255, 0, 0)  # BGR: Vermelho
            else:  # Time laranja
                color = (0, 165, 255)  # BGR: Laranja
            
            # Desenhar círculo e ID do jogador
            cv2.circle(frame, (closest_pos["x"], closest_pos["y"]), 20, color, 2)
            cv2.putText(frame, player["id"], (closest_pos["x"] - 10, closest_pos["y"] - 25),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        # Anotar bola
        if ball:
            closest_ball = min(ball, key=lambda pos: abs(pos["time"] - middle_time))
            
            # Desenhar círculo para a bola
            cv2.circle(frame, (closest_ball["x"], closest_ball["y"]), 15, (0, 255, 255), -1)  # BGR: Amarelo
        
        # Adicionar informações gerais
        cv2.putText(frame, "Rocket League Analysis", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Adicionar métricas
        metrics = analysis.get("metrics", {})
        possession = metrics.get("player_possession", {})
        
        cv2.putText(frame, f"Blue: {possession.get('blue_team', 0)}% | Orange: {possession.get('orange_team', 0)}%",
                   (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    def _annotate_rainbow_six_frame(self, frame):
        """
        Adiciona anotações a um frame de Rainbow Six Siege.
        
        Args:
            frame (numpy.ndarray): Frame a ser anotado
        """
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        players = analysis.get("detected_objects", {}).get("players", [])
        objectives = analysis.get("detected_objects", {}).get("objectives", [])
        
        # Selecionar posições para o frame atual
        middle_idx = len(self.frames) // 2
        middle_time = middle_idx / self.fps if self.fps > 0 else 0
        
        # Anotar jogadores
        for player in players:
            # Encontrar posição mais próxima do tempo atual
            positions = player["positions"]
            if not positions:
                continue
            
            closest_pos = min(positions, key=lambda pos: abs(pos["time"] - middle_time))
            
            # Definir cor com base no time
            if player["team"] == "attackers":
                color = (255, 0, 0)  # BGR: Vermelho
            else:  # defenders
                color = (0, 0, 255)  # BGR: Azul
            
            # Desenhar círculo e informações do jogador
            cv2.circle(frame, (closest_pos["x"], closest_pos["y"]), 20, color, 2)
            cv2.putText(frame, player["operator"], (closest_pos["x"] - 10, closest_pos["y"] - 25),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        # Anotar objetivos
        for obj in objectives:
            # Desenhar retângulo para o objetivo
            cv2.rectangle(frame, (obj["x"] - 30, obj["y"] - 30), (obj["x"] + 30, obj["y"] + 30),
                         (0, 255, 0), 2)  # BGR: Verde
            cv2.putText(frame, obj["id"], (obj["x"] - 20, obj["y"] - 40),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # Adicionar informações gerais
        cv2.putText(frame, "Rainbow Six Siege Analysis", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Adicionar métricas
        metrics = analysis.get("metrics", {})
        site_control = metrics.get("site_control", {})
        
        cv2.putText(frame, f"Attackers: {site_control.get('attackers', 0)}% | Defenders: {site_control.get('defenders', 0)}%",
                   (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    def _annotate_generic_frame(self, frame):
        """
        Adiciona anotações a um frame genérico.
        
        Args:
            frame (numpy.ndarray): Frame a ser anotado
        """
        # Adicionar informações gerais
        cv2.putText(frame, "Video Analysis", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        # Adicionar informações do vídeo
        cv2.putText(frame, f"Resolution: {self.width}x{self.height} | FPS: {self.fps:.2f}",
                   (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Adicionar informações de tempo
        middle_idx = len(self.frames) // 2
        middle_time = middle_idx / self.fps if self.fps > 0 else 0
        
        cv2.putText(frame, f"Time: {middle_time:.2f}s / {self.duration:.2f}s",
                   (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Adicionar borda para destacar áreas de interesse
        height, width = frame.shape[:2]
        cv2.rectangle(frame, (width//4, height//4), (3*width//4, 3*height//4),
                     (0, 255, 0), 2)  # BGR: Verde
        
        cv2.putText(frame, "Region of Interest", (width//4, height//4 - 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    def save_analysis_results(self, output_path):
        """
        Salva os resultados da análise em formato JSON.
        
        Args:
            output_path (str): Caminho para salvar o arquivo
            
        Returns:
            str: Caminho para o arquivo salvo
        """
        # Verificar se a análise foi realizada
        if not self.analysis_results:
            self.analyze_video()
        
        # Salvar como JSON
        import json
        with open(output_path, 'w') as f:
            json.dump(self.analysis_results, f, indent=2)
        
        return output_path
    
    def generate_report(self, output_path):
        """
        Gera um relatório com os resultados da análise.
        
        Args:
            output_path (str): Caminho para salvar o relatório
            
        Returns:
            str: Caminho para o relatório
        """
        # Verificar se a análise foi realizada
        if not self.analysis_results:
            self.analyze_video()
        
        # Gerar visualizações
        visualizations = self.generate_visualizations()
        
        # Criar relatório HTML
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Análise de Vídeo - {self.game_type}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1, h2, h3 {{ color: #333; }}
                .section {{ margin-bottom: 30px; }}
                .metrics {{ display: flex; flex-wrap: wrap; }}
                .metric {{ background-color: #f5f5f5; border-radius: 5px; padding: 10px; margin: 10px; flex: 1; }}
                .visualization {{ margin: 20px 0; }}
                img {{ max-width: 100%; border: 1px solid #ddd; }}
            </style>
        </head>
        <body>
            <h1>Análise de Vídeo - {self.game_type.replace('_', ' ').title()}</h1>
            
            <div class="section">
                <h2>Informações do Vídeo</h2>
                <p>Arquivo: {os.path.basename(self.video_path)}</p>
                <p>Resolução: {self.width}x{self.height}</p>
                <p>FPS: {self.fps:.2f}</p>
                <p>Duração: {self.duration:.2f} segundos</p>
                <p>Total de Frames: {self.frame_count}</p>
            </div>
        """
        
        # Adicionar seção específica para cada tipo de jogo
        if self.game_type == "rocket_league":
            html += self._generate_rocket_league_report_section(visualizations)
        elif self.game_type == "rainbow_six":
            html += self._generate_rainbow_six_report_section(visualizations)
        else:
            html += self._generate_generic_report_section(visualizations)
        
        # Finalizar HTML
        html += """
        </body>
        </html>
        """
        
        # Salvar relatório
        with open(output_path, 'w') as f:
            f.write(html)
        
        return output_path
    
    def _generate_rocket_league_report_section(self, visualizations):
        """
        Gera seção do relatório para Rocket League.
        
        Args:
            visualizations (dict): Caminhos para as visualizações
            
        Returns:
            str: HTML da seção
        """
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        metrics = analysis.get("metrics", {})
        
        html = """
            <div class="section">
                <h2>Análise de Rocket League</h2>
                
                <div class="metrics">
        """
        
        # Adicionar métricas
        possession = metrics.get("player_possession", {})
        field_control = metrics.get("field_control", {})
        boost_usage = metrics.get("boost_usage", {})
        
        html += f"""
                    <div class="metric">
                        <h3>Posse de Bola</h3>
                        <p>Time Azul: {possession.get('blue_team', 0)}%</p>
                        <p>Time Laranja: {possession.get('orange_team', 0)}%</p>
                    </div>
                    
                    <div class="metric">
                        <h3>Controle de Campo</h3>
                        <p>Time Azul: {field_control.get('blue_team', 0)}%</p>
                        <p>Time Laranja: {field_control.get('orange_team', 0)}%</p>
                    </div>
                    
                    <div class="metric">
                        <h3>Uso de Boost</h3>
                        <p>Time Azul: {boost_usage.get('blue_team', 0)}%</p>
                        <p>Time Laranja: {boost_usage.get('orange_team', 0)}%</p>
                    </div>
        """
        
        html += """
                </div>
        """
        
        # Adicionar visualizações
        for name, path in visualizations.items():
            if os.path.exists(path):
                rel_path = os.path.basename(path)
                html += f"""
                <div class="visualization">
                    <h3>{name.replace('_', ' ').title()}</h3>
                    <img src="{rel_path}" alt="{name}">
                </div>
                """
        
        # Adicionar eventos
        events = analysis.get("events", [])
        if events:
            html += """
                <div class="section">
                    <h2>Eventos Detectados</h2>
                    <table border="1" cellpadding="5" cellspacing="0" style="width: 100%;">
                        <tr>
                            <th>Tipo</th>
                            <th>Tempo</th>
                            <th>Detalhes</th>
                        </tr>
            """
            
            for event in events:
                event_type = event.get("type", "")
                event_time = event.get("time", 0)
                
                details = ""
                if event_type == "goal":
                    team = "Azul" if event.get("team", 0) == 0 else "Laranja"
                    details = f"Time {team}, Jogador: {event.get('player', 'N/A')}"
                elif event_type == "save":
                    details = f"Jogador: {event.get('player', 'N/A')}"
                elif event_type == "demolition":
                    details = f"Atacante: {event.get('attacker', 'N/A')}, Vítima: {event.get('victim', 'N/A')}"
                
                html += f"""
                        <tr>
                            <td>{event_type.title()}</td>
                            <td>{event_time:.2f}s</td>
                            <td>{details}</td>
                        </tr>
                """
            
            html += """
                    </table>
                </div>
            """
        
        html += """
            </div>
        """
        
        return html
    
    def _generate_rainbow_six_report_section(self, visualizations):
        """
        Gera seção do relatório para Rainbow Six Siege.
        
        Args:
            visualizations (dict): Caminhos para as visualizações
            
        Returns:
            str: HTML da seção
        """
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        metrics = analysis.get("metrics", {})
        
        html = """
            <div class="section">
                <h2>Análise de Rainbow Six Siege</h2>
                
                <div class="metrics">
        """
        
        # Adicionar métricas
        attacker_advantage = metrics.get("attacker_advantage", 0)
        site_control = metrics.get("site_control", {})
        operator_usage = metrics.get("operator_usage", {})
        
        html += f"""
                    <div class="metric">
                        <h3>Índice de Vantagem</h3>
                        <p>Atacantes: {max(0, attacker_advantage):.2f}</p>
                        <p>Defensores: {max(0, 1 - attacker_advantage):.2f}</p>
                    </div>
                    
                    <div class="metric">
                        <h3>Controle do Site</h3>
                        <p>Atacantes: {site_control.get('attackers', 0)}%</p>
                        <p>Defensores: {site_control.get('defenders', 0)}%</p>
                    </div>
                    
                    <div class="metric">
                        <h3>Operadores</h3>
                        <p>Mais Efetivo: {operator_usage.get('most_effective', 'N/A')}</p>
                        <p>Menos Efetivo: {operator_usage.get('least_effective', 'N/A')}</p>
                    </div>
        """
        
        html += """
                </div>
        """
        
        # Adicionar visualizações
        for name, path in visualizations.items():
            if os.path.exists(path):
                rel_path = os.path.basename(path)
                html += f"""
                <div class="visualization">
                    <h3>{name.replace('_', ' ').title()}</h3>
                    <img src="{rel_path}" alt="{name}">
                </div>
                """
        
        # Adicionar eventos
        events = analysis.get("events", [])
        if events:
            html += """
                <div class="section">
                    <h2>Eventos Detectados</h2>
                    <table border="1" cellpadding="5" cellspacing="0" style="width: 100%;">
                        <tr>
                            <th>Tipo</th>
                            <th>Tempo</th>
                            <th>Detalhes</th>
                        </tr>
            """
            
            for event in events:
                event_type = event.get("type", "")
                event_time = event.get("time", 0)
                
                details = ""
                if event_type == "kill":
                    headshot = "Headshot" if event.get("headshot", False) else ""
                    details = f"Atacante: {event.get('attacker', 'N/A')}, Vítima: {event.get('victim', 'N/A')}, Arma: {event.get('weapon', 'N/A')} {headshot}"
                elif event_type == "bomb_plant":
                    details = f"Jogador: {event.get('player', 'N/A')}, Site: {event.get('site', 'N/A')}"
                elif event_type == "bomb_defuse":
                    details = f"Jogador: {event.get('player', 'N/A')}, Site: {event.get('site', 'N/A')}"
                
                html += f"""
                        <tr>
                            <td>{event_type.replace('_', ' ').title()}</td>
                            <td>{event_time:.2f}s</td>
                            <td>{details}</td>
                        </tr>
                """
            
            html += """
                    </table>
                </div>
            """
        
        html += """
            </div>
        """
        
        return html
    
    def _generate_generic_report_section(self, visualizations):
        """
        Gera seção do relatório para análise genérica.
        
        Args:
            visualizations (dict): Caminhos para as visualizações
            
        Returns:
            str: HTML da seção
        """
        # Extrair dados da análise
        analysis = self.analysis_results.get("analysis", {})
        
        html = """
            <div class="section">
                <h2>Análise Geral do Vídeo</h2>
                
                <div class="metrics">
        """
        
        # Adicionar métricas
        motion_analysis = analysis.get("motion_analysis", {})
        
        html += f"""
                    <div class="metric">
                        <h3>Análise de Movimento</h3>
                        <p>Movimento Médio: {motion_analysis.get('average_motion', 0):.4f}</p>
                        <p>Movimento Máximo: {motion_analysis.get('max_motion', 0):.4f}</p>
                    </div>
        """
        
        # Adicionar informações sobre mudanças de cena
        scene_changes = analysis.get("scene_changes", [])
        if scene_changes:
            html += """
                    <div class="metric">
                        <h3>Mudanças de Cena</h3>
                        <ul>
            """
            
            for i, scene in enumerate(scene_changes[:5]):  # Limitar a 5 cenas
                html += f"""
                            <li>Cena {i+1}: Frame {scene.get('frame', 0)} (Tempo: {scene.get('time', 0):.2f}s)</li>
                """
            
            if len(scene_changes) > 5:
                html += f"""
                            <li>... e mais {len(scene_changes) - 5} cenas</li>
                """
            
            html += """
                        </ul>
                    </div>
            """
        
        html += """
                </div>
        """
        
        # Adicionar visualizações
        for name, path in visualizations.items():
            if os.path.exists(path):
                rel_path = os.path.basename(path)
                html += f"""
                <div class="visualization">
                    <h3>{name.replace('_', ' ').title()}</h3>
                    <img src="{rel_path}" alt="{name}">
                </div>
                """
        
        html += """
            </div>
        """
        
        return html
