"""
Módulo para diagnóstico e compatibilização de leitura de vídeos.
Este módulo implementa funções para testar diferentes métodos de leitura de vídeo
e diagnosticar problemas de compatibilidade.
"""

import os
import sys
import cv2
import numpy as np
import subprocess
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("video_diagnostics.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("VideoCompatibilityTester")

class VideoCompatibilityTester:
    """
    Classe para testar compatibilidade de vídeos e diagnosticar problemas.
    """
    
    def __init__(self, video_path, output_dir):
        """
        Inicializa o testador de compatibilidade.
        
        Args:
            video_path (str): Caminho para o arquivo de vídeo
            output_dir (str): Diretório para salvar resultados
        """
        self.video_path = video_path
        self.output_dir = output_dir
        self.results = {}
        
        # Criar diretório de saída se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        logger.info(f"Iniciando diagnóstico para vídeo: {video_path}")
    
    def run_all_tests(self):
        """
        Executa todos os testes de compatibilidade disponíveis.
        
        Returns:
            dict: Resultados dos testes
        """
        logger.info("Iniciando bateria de testes de compatibilidade")
        
        # Verificar se o arquivo existe
        if not os.path.exists(self.video_path):
            logger.error(f"Arquivo não encontrado: {self.video_path}")
            self.results["file_exists"] = False
            return self.results
        
        self.results["file_exists"] = True
        
        # Verificar tamanho do arquivo
        file_size = os.path.getsize(self.video_path)
        self.results["file_size"] = file_size
        logger.info(f"Tamanho do arquivo: {file_size} bytes")
        
        if file_size == 0:
            logger.error("Arquivo vazio")
            self.results["file_valid"] = False
            return self.results
        
        # Executar testes
        self.test_opencv_read()
        self.test_ffmpeg_info()
        self.test_file_headers()
        self.test_alternative_methods()
        
        # Tentar reparar o vídeo se necessário
        if not self.results.get("opencv_read_success", False):
            self.try_repair_video()
        
        logger.info("Testes de compatibilidade concluídos")
        return self.results
    
    def test_opencv_read(self):
        """
        Testa a leitura do vídeo usando OpenCV.
        """
        logger.info("Testando leitura com OpenCV")
        
        # Método 1: Leitura padrão
        cap = cv2.VideoCapture(self.video_path)
        success = cap.isOpened()
        self.results["opencv_read_success"] = success
        
        if success:
            # Obter informações do vídeo
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            
            self.results["video_info"] = {
                "width": width,
                "height": height,
                "fps": fps,
                "frame_count": frame_count
            }
            
            logger.info(f"Leitura bem-sucedida: {width}x{height}, {fps} FPS, {frame_count} frames")
            
            # Tentar ler alguns frames
            frames_read = 0
            for i in range(min(10, frame_count)):
                ret, frame = cap.read()
                if ret:
                    frames_read += 1
                    
                    # Salvar primeiro frame como imagem
                    if i == 0:
                        frame_path = os.path.join(self.output_dir, "first_frame.png")
                        cv2.imwrite(frame_path, frame)
                        logger.info(f"Primeiro frame salvo em: {frame_path}")
            
            self.results["frames_read"] = frames_read
            logger.info(f"Frames lidos com sucesso: {frames_read}/10")
        else:
            logger.error("Falha na leitura com OpenCV")
        
        cap.release()
        
        # Método 2: Leitura com FFMPEG explícito
        if not success:
            logger.info("Tentando leitura com FFMPEG explícito")
            cap = cv2.VideoCapture(self.video_path, cv2.CAP_FFMPEG)
            success_ffmpeg = cap.isOpened()
            self.results["opencv_ffmpeg_read_success"] = success_ffmpeg
            
            if success_ffmpeg:
                logger.info("Leitura com FFMPEG explícito bem-sucedida")
            else:
                logger.error("Falha na leitura com FFMPEG explícito")
            
            cap.release()
    
    def test_ffmpeg_info(self):
        """
        Testa a obtenção de informações do vídeo usando FFmpeg diretamente.
        """
        logger.info("Testando obtenção de informações com FFmpeg")
        
        try:
            # Executar FFmpeg para obter informações do vídeo
            cmd = ["ffprobe", "-v", "error", "-show_entries", 
                   "format=duration,size,bit_rate:stream=width,height,codec_name,codec_type", 
                   "-of", "default=noprint_wrappers=1", self.video_path]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info("FFmpeg conseguiu ler informações do vídeo")
                self.results["ffmpeg_info_success"] = True
                self.results["ffmpeg_info"] = result.stdout
                
                # Extrair informações relevantes
                info = {}
                for line in result.stdout.splitlines():
                    if "=" in line:
                        key, value = line.split("=", 1)
                        info[key.strip()] = value.strip()
                
                self.results["ffmpeg_parsed_info"] = info
                logger.info(f"Informações FFmpeg: {info}")
            else:
                logger.error(f"Falha ao obter informações com FFmpeg: {result.stderr}")
                self.results["ffmpeg_info_success"] = False
                self.results["ffmpeg_error"] = result.stderr
        
        except Exception as e:
            logger.error(f"Erro ao executar FFmpeg: {str(e)}")
            self.results["ffmpeg_info_success"] = False
            self.results["ffmpeg_error"] = str(e)
    
    def test_file_headers(self):
        """
        Testa os cabeçalhos do arquivo para verificar se é um vídeo válido.
        """
        logger.info("Analisando cabeçalhos do arquivo")
        
        try:
            with open(self.video_path, 'rb') as f:
                header = f.read(16)  # Ler primeiros 16 bytes
            
            # Converter para hexadecimal para análise
            hex_header = ' '.join([f'{b:02x}' for b in header])
            self.results["file_header"] = hex_header
            logger.info(f"Cabeçalho do arquivo (hex): {hex_header}")
            
            # Verificar assinaturas comuns de formatos de vídeo
            is_mp4 = header[4:8] == b'ftyp'
            is_avi = header[:4] == b'RIFF' and header[8:12] == b'AVI '
            is_mkv = header[:4] == b'\x1a\x45\xdf\xa3'
            is_webm = header[:4] == b'\x1a\x45\xdf\xa3'  # Mesmo que MKV (Matroska)
            
            self.results["file_format"] = {
                "is_mp4": is_mp4,
                "is_avi": is_avi,
                "is_mkv": is_mkv,
                "is_webm": is_webm
            }
            
            if is_mp4:
                logger.info("Arquivo identificado como MP4")
            elif is_avi:
                logger.info("Arquivo identificado como AVI")
            elif is_mkv or is_webm:
                logger.info("Arquivo identificado como MKV/WebM")
            else:
                logger.warning("Formato de arquivo não reconhecido")
        
        except Exception as e:
            logger.error(f"Erro ao analisar cabeçalhos: {str(e)}")
            self.results["file_header_error"] = str(e)
    
    def test_alternative_methods(self):
        """
        Testa métodos alternativos de leitura de vídeo.
        """
        logger.info("Testando métodos alternativos de leitura")
        
        # Método 1: Usar subprocess para extrair um frame com FFmpeg
        try:
            output_frame = os.path.join(self.output_dir, "ffmpeg_frame.png")
            cmd = ["ffmpeg", "-i", self.video_path, "-vframes", "1", "-q:v", "1", output_frame]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0 and os.path.exists(output_frame):
                logger.info("FFmpeg conseguiu extrair um frame")
                self.results["ffmpeg_frame_success"] = True
            else:
                logger.error(f"Falha ao extrair frame com FFmpeg: {result.stderr}")
                self.results["ffmpeg_frame_success"] = False
                self.results["ffmpeg_frame_error"] = result.stderr
        
        except Exception as e:
            logger.error(f"Erro ao executar FFmpeg para extração de frame: {str(e)}")
            self.results["ffmpeg_frame_success"] = False
            self.results["ffmpeg_frame_error"] = str(e)
    
    def try_repair_video(self):
        """
        Tenta reparar o vídeo usando FFmpeg.
        """
        logger.info("Tentando reparar o vídeo")
        
        try:
            repaired_path = os.path.join(self.output_dir, "repaired_video.mp4")
            
            # Usar FFmpeg para tentar reparar o vídeo
            cmd = ["ffmpeg", "-err_detect", "ignore_err", "-i", self.video_path, 
                   "-c", "copy", repaired_path]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0 and os.path.exists(repaired_path):
                logger.info(f"Vídeo reparado salvo em: {repaired_path}")
                self.results["repair_success"] = True
                self.results["repaired_path"] = repaired_path
                
                # Testar se o vídeo reparado pode ser lido
                cap = cv2.VideoCapture(repaired_path)
                if cap.isOpened():
                    logger.info("Vídeo reparado pode ser lido com OpenCV")
                    self.results["repaired_video_readable"] = True
                else:
                    logger.warning("Vídeo reparado ainda não pode ser lido com OpenCV")
                    self.results["repaired_video_readable"] = False
                
                cap.release()
            else:
                logger.error(f"Falha ao reparar vídeo: {result.stderr}")
                self.results["repair_success"] = False
                self.results["repair_error"] = result.stderr
        
        except Exception as e:
            logger.error(f"Erro ao tentar reparar vídeo: {str(e)}")
            self.results["repair_success"] = False
            self.results["repair_error"] = str(e)
    
    def generate_report(self):
        """
        Gera um relatório com os resultados dos testes.
        
        Returns:
            str: Caminho para o arquivo de relatório
        """
        logger.info("Gerando relatório de diagnóstico")
        
        report_path = os.path.join(self.output_dir, "video_diagnostics_report.txt")
        
        with open(report_path, 'w') as f:
            f.write("=== RELATÓRIO DE DIAGNÓSTICO DE VÍDEO ===\n")
            f.write(f"Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Arquivo: {self.video_path}\n")
            f.write("\n")
            
            # Resumo
            f.write("=== RESUMO ===\n")
            if not self.results.get("file_exists", False):
                f.write("ERRO: Arquivo não encontrado\n")
            elif self.results.get("opencv_read_success", False):
                f.write("STATUS: Vídeo pode ser lido normalmente com OpenCV\n")
            elif self.results.get("opencv_ffmpeg_read_success", False):
                f.write("STATUS: Vídeo pode ser lido com OpenCV usando FFMPEG explícito\n")
            elif self.results.get("ffmpeg_info_success", False):
                f.write("STATUS: Vídeo pode ser lido com FFmpeg, mas não com OpenCV\n")
            elif self.results.get("repair_success", False) and self.results.get("repaired_video_readable", False):
                f.write("STATUS: Vídeo original com problemas, mas foi reparado com sucesso\n")
            else:
                f.write("STATUS: Vídeo não pode ser lido por nenhum método testado\n")
            f.write("\n")
            
            # Detalhes do arquivo
            f.write("=== DETALHES DO ARQUIVO ===\n")
            f.write(f"Tamanho: {self.results.get('file_size', 'N/A')} bytes\n")
            
            file_format = self.results.get("file_format", {})
            if file_format:
                format_name = "Desconhecido"
                if file_format.get("is_mp4", False):
                    format_name = "MP4"
                elif file_format.get("is_avi", False):
                    format_name = "AVI"
                elif file_format.get("is_mkv", False) or file_format.get("is_webm", False):
                    format_name = "MKV/WebM"
                
                f.write(f"Formato identificado: {format_name}\n")
                f.write(f"Cabeçalho: {self.results.get('file_header', 'N/A')}\n")
            f.write("\n")
            
            # Resultados OpenCV
            f.write("=== RESULTADOS OPENCV ===\n")
            f.write(f"Leitura padrão: {'Sucesso' if self.results.get('opencv_read_success', False) else 'Falha'}\n")
            f.write(f"Leitura FFMPEG explícito: {'Sucesso' if self.results.get('opencv_ffmpeg_read_success', False) else 'Falha'}\n")
            
            video_info = self.results.get("video_info", {})
            if video_info:
                f.write(f"Resolução: {video_info.get('width', 'N/A')}x{video_info.get('height', 'N/A')}\n")
                f.write(f"FPS: {video_info.get('fps', 'N/A')}\n")
                f.write(f"Total de frames: {video_info.get('frame_count', 'N/A')}\n")
                f.write(f"Frames lidos: {self.results.get('frames_read', 'N/A')}/10\n")
            f.write("\n")
            
            # Resultados FFmpeg
            f.write("=== RESULTADOS FFMPEG ===\n")
            f.write(f"Leitura de informações: {'Sucesso' if self.results.get('ffmpeg_info_success', False) else 'Falha'}\n")
            f.write(f"Extração de frame: {'Sucesso' if self.results.get('ffmpeg_frame_success', False) else 'Falha'}\n")
            
            ffmpeg_info = self.results.get("ffmpeg_parsed_info", {})
            if ffmpeg_info:
                f.write("Informações do vídeo:\n")
                for key, value in ffmpeg_info.items():
                    f.write(f"  {key}: {value}\n")
            
            if "ffmpeg_error" in self.results:
                f.write(f"Erro FFmpeg: {self.results['ffmpeg_error']}\n")
            f.write("\n")
            
            # Resultados de reparo
            f.write("=== RESULTADOS DE REPARO ===\n")
            if "repair_success" in self.results:
                f.write(f"Tentativa de reparo: {'Sucesso' if self.results['repair_success'] else 'Falha'}\n")
                
                if self.results.get("repair_success", False):
                    f.write(f"Vídeo reparado: {self.results.get('repaired_path', 'N/A')}\n")
                    f.write(f"Vídeo reparado legível: {'Sim' if self.results.get('repaired_video_readable', False) else 'Não'}\n")
                
                if "repair_error" in self.results:
                    f.write(f"Erro de reparo: {self.results['repair_error']}\n")
            else:
                f.write("Reparo não tentado\n")
            f.write("\n")
            
            # Recomendações
            f.write("=== RECOMENDAÇÕES ===\n")
            if not self.results.get("file_exists", False):
                f.write("- Verifique se o caminho do arquivo está correto\n")
            elif self.results.get("opencv_read_success", False) or self.results.get("opencv_ffmpeg_read_success", False):
                f.write("- O vídeo pode ser processado normalmente\n")
            elif self.results.get("repair_success", False) and self.results.get("repaired_video_readable", False):
                f.write("- Use o vídeo reparado para processamento\n")
            elif self.results.get("ffmpeg_info_success", False):
                f.write("- O vídeo pode ser processado com FFmpeg, mas não com OpenCV\n")
                f.write("- Considere converter o vídeo para outro formato\n")
            else:
                f.write("- O arquivo parece estar corrompido ou em formato incompatível\n")
                f.write("- Tente converter o vídeo para um formato padrão como MP4 com H.264\n")
                f.write("- Verifique se o vídeo pode ser aberto em players como VLC\n")
        
        logger.info(f"Relatório gerado em: {report_path}")
        return report_path


def main():
    """
    Função principal para execução do diagnóstico.
    """
    if len(sys.argv) < 2:
        print("Uso: python video_diagnostics.py <caminho_do_video> [diretorio_saida]")
        return
    
    video_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "video_diagnostics_output"
    
    tester = VideoCompatibilityTester(video_path, output_dir)
    tester.run_all_tests()
    report_path = tester.generate_report()
    
    print(f"Diagnóstico concluído. Relatório salvo em: {report_path}")


if __name__ == "__main__":
    main()
