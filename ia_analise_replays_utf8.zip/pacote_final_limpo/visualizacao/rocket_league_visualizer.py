"""
Visualizador para replays de Rocket League.
Este módulo implementa funções para visualizar dados extraídos de replays do Rocket League.
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

class RocketLeagueVisualizer:
    """
    Visualizador para replays de Rocket League.
    
    Esta classe implementa métodos para visualizar dados extraídos de replays do Rocket League
    e gerar gráficos e visualizações para análise.
    """
    
    def __init__(self, output_dir):
        """
        Inicializa o visualizador.
        
        Args:
            output_dir (str): Diretório para salvar as visualizações
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def _convert_to_dataframe(self, data_dict):
        """
        Converte dados de dicionário para DataFrame.
        
        Args:
            data_dict (dict): Dicionário com dados
            
        Returns:
            pandas.DataFrame: DataFrame com dados convertidos
        """
        # Implementação básica para converter dicionário em DataFrame
        # Esta função deve ser adaptada conforme a estrutura específica dos dados
        
        if not data_dict or not isinstance(data_dict, dict):
            return pd.DataFrame()
        
        # Tentar extrair dados de jogadores
        if "players" in data_dict:
            players_data = []
            for player in data_dict["players"]:
                player_id = player.get("id", "unknown")
                team = player.get("team", 0)
                
                # Extrair frames se disponíveis
                if "frames" in data_dict:
                    for frame_idx, frame in enumerate(data_dict["frames"]):
                        if "players" in frame and player_id in frame["players"]:
                            player_frame = frame["players"][player_id]
                            players_data.append({
                                "player_id": player_id,
                                "team": team,
                                "frame": frame_idx,
                                "time": frame_idx / 30,  # Assumindo 30 FPS
                                "x": player_frame.get("x", 0),
                                "y": player_frame.get("y", 0),
                                "z": player_frame.get("z", 0),
                                "boost": player_frame.get("boost", 0),
                                "speed": player_frame.get("speed", 0)
                            })
            
            if players_data:
                return pd.DataFrame(players_data)
        
        # Fallback: criar DataFrame vazio com colunas esperadas
        return pd.DataFrame(columns=["player_id", "team", "frame", "time", "x", "y", "z", "boost", "speed"])
    
    def _extract_ball_data(self, data_dict):
        """
        Extrai dados da bola de um dicionário.
        
        Args:
            data_dict (dict): Dicionário com dados
            
        Returns:
            pandas.DataFrame: DataFrame com dados da bola
        """
        if not data_dict or not isinstance(data_dict, dict):
            return pd.DataFrame()
        
        # Tentar extrair dados da bola
        ball_data = []
        if "frames" in data_dict:
            for frame_idx, frame in enumerate(data_dict["frames"]):
                if "ball" in frame:
                    ball_frame = frame["ball"]
                    ball_data.append({
                        "frame": frame_idx,
                        "time": frame_idx / 30,  # Assumindo 30 FPS
                        "x": ball_frame.get("x", 0),
                        "y": ball_frame.get("y", 0),
                        "z": ball_frame.get("z", 0)
                    })
        
        if ball_data:
            return pd.DataFrame(ball_data)
        
        # Fallback: criar DataFrame vazio com colunas esperadas
        return pd.DataFrame(columns=["frame", "time", "x", "y", "z"])
    
    def plot_player_positions(self, replay_data):
        """
        Plota as posições dos jogadores ao longo do tempo.
        
        Args:
            replay_data (dict): Dados do replay
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        # Converter para DataFrame se necessário
        if isinstance(replay_data, dict):
            player_df = self._convert_to_dataframe(replay_data)
        else:
            player_df = replay_data
            
        if player_df.empty:
            # Criar imagem vazia com mensagem
            plt.figure(figsize=(12, 8))
            plt.text(0.5, 0.5, "Dados insuficientes para visualização", 
                    horizontalalignment='center', verticalalignment='center',
                    transform=plt.gca().transAxes, fontsize=14)
            plt.axis('off')
            output_path = os.path.join(self.output_dir, "player_positions.png")
            plt.savefig(output_path)
            plt.close()
            return output_path
            
        # Criar figura
        plt.figure(figsize=(12, 8))
        
        # Definir limites do campo (aproximados para Rocket League)
        field_length = 10240  # Comprimento do campo
        field_width = 8192    # Largura do campo
        
        # Plotar campo
        plt.plot([-field_length/2, field_length/2, field_length/2, -field_length/2, -field_length/2],
                 [-field_width/2, -field_width/2, field_width/2, field_width/2, -field_width/2],
                 'k-', linewidth=2)
        
        # Plotar linha do meio
        plt.plot([0, 0], [-field_width/2, field_width/2], 'k--', linewidth=1)
        
        # Plotar círculo central
        circle = plt.Circle((0, 0), 1024, fill=False, linestyle='--', linewidth=1)
        plt.gca().add_patch(circle)
        
        # Plotar gols
        goal_width = 1786
        plt.plot([-field_length/2, -field_length/2], [-goal_width/2, goal_width/2], 'b-', linewidth=3)
        plt.plot([field_length/2, field_length/2], [-goal_width/2, goal_width/2], 'r-', linewidth=3)
        
        # Plotar posições dos jogadores por time
        for team in player_df['team'].unique():
            team_data = player_df[player_df['team'] == team]
            
            for player_id in team_data['player_id'].unique():
                player_data = team_data[team_data['player_id'] == player_id]
                
                if team == 0:  # Time azul
                    color = 'blue'
                else:  # Time laranja
                    color = 'orange'
                
                plt.scatter(player_data['x'], player_data['y'], s=10, alpha=0.5, color=color, label=f"Player {player_id}")
        
        # Configurar gráfico
        plt.title("Posições dos Jogadores no Campo")
        plt.xlabel("Eixo X")
        plt.ylabel("Eixo Y")
        plt.axis('equal')
        plt.grid(True)
        
        # Remover legendas duplicadas
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), loc='upper right')
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "player_positions.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def plot_heatmap(self, player_df):
        """
        Plota um mapa de calor das posições dos jogadores.
        
        Args:
            player_df (pandas.DataFrame ou dict): DataFrame ou dicionário com posições dos jogadores
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        # Converter para DataFrame se necessário
        if isinstance(player_df, dict):
            player_df = self._convert_to_dataframe(player_df)
            
        if player_df.empty:
            # Criar imagem vazia com mensagem
            plt.figure(figsize=(12, 8))
            plt.text(0.5, 0.5, "Dados insuficientes para visualização", 
                    horizontalalignment='center', verticalalignment='center',
                    transform=plt.gca().transAxes, fontsize=14)
            plt.axis('off')
            output_path = os.path.join(self.output_dir, "heatmap.png")
            plt.savefig(output_path)
            plt.close()
            return output_path
        
        # Criar figura
        plt.figure(figsize=(12, 10))
        
        # Separar times
        blue_team = player_df[player_df["team"] == 0]
        orange_team = player_df[player_df["team"] == 1]
        
        # Criar subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # Definir limites do campo (aproximados para Rocket League)
        field_length = 10240  # Comprimento do campo
        field_width = 8192    # Largura do campo
        
        # Mapa de calor para time azul
        if not blue_team.empty:
            sns.kdeplot(x=blue_team["x"], y=blue_team["y"], cmap="Blues", fill=True, alpha=0.7, ax=ax1)
            ax1.set_title("Mapa de Calor - Time Azul")
            ax1.set_xlim(-field_length/2, field_length/2)
            ax1.set_ylim(-field_width/2, field_width/2)
            ax1.grid(True)
        
        # Mapa de calor para time laranja
        if not orange_team.empty:
            sns.kdeplot(x=orange_team["x"], y=orange_team["y"], cmap="Oranges", fill=True, alpha=0.7, ax=ax2)
            ax2.set_title("Mapa de Calor - Time Laranja")
            ax2.set_xlim(-field_length/2, field_length/2)
            ax2.set_ylim(-field_width/2, field_width/2)
            ax2.grid(True)
        
        # Ajustar layout
        plt.tight_layout()
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "heatmap.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def plot_ball_trajectory(self, ball_df):
        """
        Plota a trajetória da bola ao longo do tempo.
        
        Args:
            ball_df (pandas.DataFrame ou dict): DataFrame ou dicionário com posições da bola
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        # Converter para DataFrame se necessário
        if isinstance(ball_df, dict):
            ball_df = self._extract_ball_data(ball_df)
            
        if ball_df.empty:
            # Criar imagem vazia com mensagem
            plt.figure(figsize=(12, 8))
            plt.text(0.5, 0.5, "Dados insuficientes para visualização", 
                    horizontalalignment='center', verticalalignment='center',
                    transform=plt.gca().transAxes, fontsize=14)
            plt.axis('off')
            output_path = os.path.join(self.output_dir, "ball_trajectory.png")
            plt.savefig(output_path)
            plt.close()
            return output_path
        
        # Criar figura
        plt.figure(figsize=(12, 8))
        
        # Definir limites do campo (aproximados para Rocket League)
        field_length = 10240  # Comprimento do campo
        field_width = 8192    # Largura do campo
        
        # Plotar campo
        plt.plot([-field_length/2, field_length/2, field_length/2, -field_length/2, -field_length/2],
                 [-field_width/2, -field_width/2, field_width/2, field_width/2, -field_width/2],
                 'k-', linewidth=2)
        
        # Plotar linha do meio
        plt.plot([0, 0], [-field_width/2, field_width/2], 'k--', linewidth=1)
        
        # Plotar círculo central
        circle = plt.Circle((0, 0), 1024, fill=False, linestyle='--', linewidth=1)
        plt.gca().add_patch(circle)
        
        # Plotar gols
        goal_width = 1786
        plt.plot([-field_length/2, -field_length/2], [-goal_width/2, goal_width/2], 'b-', linewidth=3)
        plt.plot([field_length/2, field_length/2], [-goal_width/2, goal_width/2], 'r-', linewidth=3)
        
        # Plotar trajetória da bola
        plt.scatter(ball_df["x"], ball_df["y"], c=ball_df["time"], cmap="viridis", s=10, alpha=0.7)
        
        # Adicionar barra de cores
        cbar = plt.colorbar()
        cbar.set_label("Tempo (s)")
        
        # Configurar gráfico
        plt.title("Trajetória da Bola")
        plt.xlabel("Eixo X")
        plt.ylabel("Eixo Y")
        plt.axis('equal')
        plt.grid(True)
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "ball_trajectory.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def plot_boost_usage(self, player_df):
        """
        Plota o uso de boost pelos jogadores ao longo do tempo.
        
        Args:
            player_df (pandas.DataFrame ou dict): DataFrame ou dicionário com dados dos jogadores
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        # Converter para DataFrame se necessário
        if isinstance(player_df, dict):
            player_df = self._convert_to_dataframe(player_df)
            
        if player_df.empty or "boost" not in player_df.columns:
            # Criar imagem vazia com mensagem
            plt.figure(figsize=(12, 8))
            plt.text(0.5, 0.5, "Dados insuficientes para visualização de boost", 
                    horizontalalignment='center', verticalalignment='center',
                    transform=plt.gca().transAxes, fontsize=14)
            plt.axis('off')
            output_path = os.path.join(self.output_dir, "boost_usage.png")
            plt.savefig(output_path)
            plt.close()
            return output_path
        
        # Criar figura
        plt.figure(figsize=(12, 8))
        
        # Agrupar por jogador e tempo
        players = player_df["player_id"].unique()
        
        # Plotar boost para cada jogador
        for player_id in players:
            player_data = player_df[player_df["player_id"] == player_id]
            team = player_data["team"].iloc[0]
            
            if team == 0:  # Time azul
                color = 'blue'
            else:  # Time laranja
                color = 'orange'
            
            plt.plot(player_data["time"], player_data["boost"], color=color, alpha=0.7, label=f"Player {player_id}")
        
        # Configurar gráfico
        plt.title("Uso de Boost ao Longo do Tempo")
        plt.xlabel("Tempo (s)")
        plt.ylabel("Boost")
        plt.ylim(0, 100)
        plt.grid(True)
        
        # Remover legendas duplicadas
        handles, labels = plt.gca().get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        plt.legend(by_label.values(), by_label.keys(), loc='upper right')
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "boost_usage.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def plot_speed_distribution(self, player_df):
        """
        Plota a distribuição de velocidade dos jogadores.
        
        Args:
            player_df (pandas.DataFrame ou dict): DataFrame ou dicionário com dados dos jogadores
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        # Converter para DataFrame se necessário
        if isinstance(player_df, dict):
            player_df = self._convert_to_dataframe(player_df)
            
        if player_df.empty or "speed" not in player_df.columns:
            # Criar imagem vazia com mensagem
            plt.figure(figsize=(12, 8))
            plt.text(0.5, 0.5, "Dados insuficientes para visualização de velocidade", 
                    horizontalalignment='center', verticalalignment='center',
                    transform=plt.gca().transAxes, fontsize=14)
            plt.axis('off')
            output_path = os.path.join(self.output_dir, "speed_distribution.png")
            plt.savefig(output_path)
            plt.close()
            return output_path
        
        # Criar figura
        plt.figure(figsize=(12, 8))
        
        # Separar times
        blue_team = player_df[player_df["team"] == 0]
        orange_team = player_df[player_df["team"] == 1]
        
        # Plotar distribuição de velocidade
        if not blue_team.empty:
            sns.kdeplot(blue_team["speed"], color="blue", label="Time Azul", fill=True, alpha=0.3)
        
        if not orange_team.empty:
            sns.kdeplot(orange_team["speed"], color="orange", label="Time Laranja", fill=True, alpha=0.3)
        
        # Configurar gráfico
        plt.title("Distribuição de Velocidade")
        plt.xlabel("Velocidade")
        plt.ylabel("Densidade")
        plt.grid(True)
        plt.legend()
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "speed_distribution.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def plot_analysis_radar(self, analysis_results):
        """
        Plota um gráfico radar com os resultados da análise.
        
        Args:
            analysis_results (dict): Resultados da análise
            
        Returns:
            str: Caminho para o arquivo de imagem gerado
        """
        if not analysis_results:
            # Criar dados simulados para demonstração
            analysis_results = {
                "positioning_score": 75,
                "boost_score": 65,
                "rotation_score": 80,
                "team_stats": {
                    "blue": {
                        "offensive_rating": 70,
                        "defensive_rating": 85
                    },
                    "orange": {
                        "offensive_rating": 75,
                        "defensive_rating": 60
                    }
                }
            }
        
        # Criar figura
        plt.figure(figsize=(10, 8))
        
        # Definir categorias e valores
        categories = ['Posicionamento', 'Boost', 'Rotação', 'Ataque', 'Defesa']
        
        # Extrair valores para time azul
        blue_values = [
            analysis_results.get("positioning_score", 0),
            analysis_results.get("boost_score", 0),
            analysis_results.get("rotation_score", 0),
            analysis_results.get("team_stats", {}).get("blue", {}).get("offensive_rating", 0),
            analysis_results.get("team_stats", {}).get("blue", {}).get("defensive_rating", 0)
        ]
        
        # Extrair valores para time laranja
        orange_values = [
            analysis_results.get("positioning_score", 0),
            analysis_results.get("boost_score", 0),
            analysis_results.get("rotation_score", 0),
            analysis_results.get("team_stats", {}).get("orange", {}).get("offensive_rating", 0),
            analysis_results.get("team_stats", {}).get("orange", {}).get("defensive_rating", 0)
        ]
        
        # Número de variáveis
        N = len(categories)
        
        # Ângulos para cada eixo
        angles = [n / float(N) * 2 * np.pi for n in range(N)]
        angles += angles[:1]  # Fechar o círculo
        
        # Adicionar valores para fechar o círculo
        blue_values += blue_values[:1]
        orange_values += orange_values[:1]
        
        # Configurar radar
        ax = plt.subplot(111, polar=True)
        
        # Plotar time azul
        ax.plot(angles, blue_values, 'b-', linewidth=2, label='Time Azul')
        ax.fill(angles, blue_values, 'b', alpha=0.1)
        
        # Plotar time laranja
        ax.plot(angles, orange_values, 'orange', linewidth=2, label='Time Laranja')
        ax.fill(angles, orange_values, 'orange', alpha=0.1)
        
        # Configurar eixos
        plt.xticks(angles[:-1], categories)
        ax.set_rlabel_position(0)
        plt.yticks([20, 40, 60, 80, 100], ["20", "40", "60", "80", "100"], color="grey", size=8)
        plt.ylim(0, 100)
        
        # Adicionar título e legenda
        plt.title("Análise de Desempenho", size=14)
        plt.legend(loc='upper right')
        
        # Salvar figura
        output_path = os.path.join(self.output_dir, "analysis_radar.png")
        plt.savefig(output_path)
        plt.close()
        
        return output_path
    
    def generate_all_visualizations(self, replay_data, player_df=None, ball_df=None, analysis_results=None):
        """
        Gera todas as visualizações disponíveis.
        
        Args:
            replay_data (dict): Dados do replay
            player_df (pandas.DataFrame, opcional): DataFrame com dados dos jogadores
            ball_df (pandas.DataFrame, opcional): DataFrame com dados da bola
            analysis_results (dict, opcional): Resultados da análise
            
        Returns:
            dict: Caminhos para os arquivos de imagem gerados
        """
        visualizations = {}
        
        # Converter dados se necessário
        if player_df is None and isinstance(replay_data, dict):
            player_df = self._convert_to_dataframe(replay_data)
        
        if ball_df is None and isinstance(replay_data, dict):
            ball_df = self._extract_ball_data(replay_data)
        
        # Gerar visualizações
        visualizations["player_positions"] = self.plot_player_positions(replay_data if player_df is None else player_df)
        visualizations["heatmap"] = self.plot_heatmap(player_df if player_df is not None else replay_data)
        visualizations["ball_trajectory"] = self.plot_ball_trajectory(ball_df if ball_df is not None else replay_data)
        visualizations["boost_usage"] = self.plot_boost_usage(player_df if player_df is not None else replay_data)
        visualizations["speed_distribution"] = self.plot_speed_distribution(player_df if player_df is not None else replay_data)
        visualizations["analysis_radar"] = self.plot_analysis_radar(analysis_results if analysis_results is not None else {})
        
        return visualizations
