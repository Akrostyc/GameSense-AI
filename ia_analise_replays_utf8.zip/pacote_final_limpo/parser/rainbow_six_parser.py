"""
Parser para arquivos de replay do Rainbow Six Siege.
Este módulo implementa funções para extrair dados de arquivos .rec do Rainbow Six Siege.
"""

import os
import json
import struct
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

class RainbowSixReplayParser:
    """
    Parser para arquivos de replay do Rainbow Six Siege.
    
    Esta classe implementa métodos para extrair dados de arquivos .rec do Rainbow Six Siege.
    """
    
    def __init__(self, file_path):
        """
        Inicializa o parser.
        
        Args:
            file_path (str): Caminho para o arquivo .rec
        """
        self.file_path = file_path
        self.match_info = None
        self.player_stats = None
        self.round_stats = None
        self.events = None
    
    def parse(self):
        """
        Analisa o arquivo de replay e extrai os dados.
        
        Returns:
            bool: True se o parsing for bem-sucedido, False caso contrário
        """
        try:
            # Simular parsing do arquivo .rec
            self.match_info = self._extract_match_info()
            self.player_stats = self._extract_player_stats()
            self.round_stats = self._extract_round_stats()
            self.events = self._extract_events()
            
            return True
        except Exception as e:
            print(f"Erro ao analisar o replay: {str(e)}")
            return False
    
    def _extract_match_info(self):
        """
        Extrai informações básicas da partida.
        
        Returns:
            dict: Informações da partida
        """
        # Verificar se o arquivo existe
        if not os.path.exists(self.file_path):
            print(f"Arquivo não encontrado: {self.file_path}")
            return None
        
        # Simular dados da partida
        match_info = {
            "id": "r6s-12345678-1234-5678-1234-567812345678",
            "map": "Clubhouse",
            "game_mode": "Bomb",
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "duration": 1800,  # 30 minutos
            "region": "South America",
            "playlist": "Ranked",
            "match_type": "Online"
        }
        
        return match_info
    
    def _extract_player_stats(self):
        """
        Extrai estatísticas dos jogadores.
        
        Returns:
            list: Lista de estatísticas dos jogadores
        """
        # Simular estatísticas dos jogadores
        players = [
            {
                "id": "player1",
                "name": "Attacker1",
                "team": "Attackers",
                "operator": "Ash",
                "kills": 7,
                "deaths": 4,
                "assists": 2,
                "headshots": 3,
                "score": 4500
            },
            {
                "id": "player2",
                "name": "Attacker2",
                "team": "Attackers",
                "operator": "Thermite",
                "kills": 5,
                "deaths": 5,
                "assists": 3,
                "headshots": 2,
                "score": 3800
            },
            {
                "id": "player3",
                "name": "Attacker3",
                "team": "Attackers",
                "operator": "Thatcher",
                "kills": 4,
                "deaths": 6,
                "assists": 4,
                "headshots": 1,
                "score": 3200
            },
            {
                "id": "player4",
                "name": "Attacker4",
                "team": "Attackers",
                "operator": "Sledge",
                "kills": 6,
                "deaths": 5,
                "assists": 1,
                "headshots": 4,
                "score": 4200
            },
            {
                "id": "player5",
                "name": "Attacker5",
                "team": "Attackers",
                "operator": "IQ",
                "kills": 3,
                "deaths": 7,
                "assists": 5,
                "headshots": 2,
                "score": 3500
            },
            {
                "id": "player6",
                "name": "Defender1",
                "team": "Defenders",
                "operator": "Jager",
                "kills": 6,
                "deaths": 5,
                "assists": 2,
                "headshots": 3,
                "score": 4300
            },
            {
                "id": "player7",
                "name": "Defender2",
                "team": "Defenders",
                "operator": "Bandit",
                "kills": 5,
                "deaths": 4,
                "assists": 3,
                "headshots": 2,
                "score": 3900
            },
            {
                "id": "player8",
                "name": "Defender3",
                "team": "Defenders",
                "operator": "Mute",
                "kills": 7,
                "deaths": 3,
                "assists": 1,
                "headshots": 5,
                "score": 4700
            },
            {
                "id": "player9",
                "name": "Defender4",
                "team": "Defenders",
                "operator": "Rook",
                "kills": 4,
                "deaths": 6,
                "assists": 4,
                "headshots": 1,
                "score": 3400
            },
            {
                "id": "player10",
                "name": "Defender5",
                "team": "Defenders",
                "operator": "Doc",
                "kills": 5,
                "deaths": 7,
                "assists": 3,
                "headshots": 2,
                "score": 3600
            }
        ]
        
        return players
    
    def _extract_round_stats(self):
        """
        Extrai estatísticas das rodadas.
        
        Returns:
            list: Lista de estatísticas das rodadas
        """
        # Simular estatísticas das rodadas
        rounds = [
            {
                "round": 1,
                "winner": "Defenders",
                "site": "Basement",
                "duration": 180,  # 3 minutos
                "objective_achieved": False,
                "elimination": True
            },
            {
                "round": 2,
                "winner": "Attackers",
                "site": "Basement",
                "duration": 165,
                "objective_achieved": True,
                "elimination": False
            },
            {
                "round": 3,
                "winner": "Defenders",
                "site": "Bar",
                "duration": 210,
                "objective_achieved": False,
                "elimination": True
            },
            {
                "round": 4,
                "winner": "Attackers",
                "site": "Bar",
                "duration": 190,
                "objective_achieved": True,
                "elimination": False
            },
            {
                "round": 5,
                "winner": "Attackers",
                "site": "Bedroom",
                "duration": 175,
                "objective_achieved": False,
                "elimination": True
            },
            {
                "round": 6,
                "winner": "Defenders",
                "site": "Bedroom",
                "duration": 195,
                "objective_achieved": False,
                "elimination": True
            },
            {
                "round": 7,
                "winner": "Attackers",
                "site": "Basement",
                "duration": 185,
                "objective_achieved": True,
                "elimination": False
            },
            {
                "round": 8,
                "winner": "Attackers",
                "site": "Bar",
                "duration": 170,
                "objective_achieved": False,
                "elimination": True
            },
            {
                "round": 9,
                "winner": "Defenders",
                "site": "Bedroom",
                "duration": 200,
                "objective_achieved": False,
                "elimination": True
            }
        ]
        
        return rounds
    
    def _extract_events(self):
        """
        Extrai eventos do replay.
        
        Returns:
            list: Lista de eventos
        """
        # Simular eventos do replay
        events = []
        
        # Gerar eventos para cada rodada
        for round_num in range(1, 10):
            round_start_time = (round_num - 1) * 200  # Aproximadamente 3 minutos por rodada + preparação
            
            # Evento de início de rodada
            events.append({
                "type": "round_start",
                "round": round_num,
                "time": round_start_time,
                "site": self.round_stats[round_num - 1]["site"]
            })
            
            # Simular alguns abates
            for i in range(5):  # Alguns abates por rodada
                kill_time = round_start_time + 30 + i * 30  # Distribuir ao longo da rodada
                
                # Determinar atacante e vítima
                if i % 2 == 0:
                    attacker_team = "Attackers"
                    victim_team = "Defenders"
                    attacker_idx = (i + round_num) % 5
                    victim_idx = (i + round_num + 2) % 5
                else:
                    attacker_team = "Defenders"
                    victim_team = "Attackers"
                    attacker_idx = (i + round_num) % 5
                    victim_idx = (i + round_num + 3) % 5
                
                # Encontrar jogadores correspondentes
                attacker = None
                victim = None
                
                for player in self.player_stats:
                    if player["team"] == attacker_team and int(player["id"][-1]) == attacker_idx + 1:
                        attacker = player
                    if player["team"] == victim_team and int(player["id"][-1]) == victim_idx + 1:
                        victim = player
                
                if attacker and victim:
                    events.append({
                        "type": "kill",
                        "round": round_num,
                        "time": kill_time,
                        "attacker": attacker["id"],
                        "attacker_name": attacker["name"],
                        "attacker_operator": attacker["operator"],
                        "victim": victim["id"],
                        "victim_name": victim["name"],
                        "victim_operator": victim["operator"],
                        "headshot": (i + round_num) % 3 == 0,  # Alguns headshots
                        "weapon": self._get_random_weapon(attacker["operator"])
                    })
            
            # Evento de fim de rodada
            events.append({
                "type": "round_end",
                "round": round_num,
                "time": round_start_time + self.round_stats[round_num - 1]["duration"],
                "winner": self.round_stats[round_num - 1]["winner"],
                "reason": "elimination" if self.round_stats[round_num - 1]["elimination"] else "objective"
            })
        
        return events
    
    def _get_random_weapon(self, operator):
        """
        Retorna uma arma aleatória para o operador.
        
        Args:
            operator (str): Nome do operador
            
        Returns:
            str: Nome da arma
        """
        # Mapear operadores para armas comuns
        weapons = {
            "Ash": ["R4-C", "G36C", "M45 MEUSOC"],
            "Thermite": ["556XI", "M1014", "5.7 USG"],
            "Thatcher": ["AR33", "L85A2", "P226 MK 25"],
            "Sledge": ["L85A2", "M590A1", "P226 MK 25"],
            "IQ": ["AUG A2", "552 Commando", "P12"],
            "Jager": ["416-C Carbine", "M870", "P12"],
            "Bandit": ["MP7", "M870", "P12"],
            "Mute": ["MP5K", "M590A1", "P226 MK 25"],
            "Rook": ["MP5", "P90", "LFP586"],
            "Doc": ["MP5", "P90", "LFP586"]
        }
        
        if operator in weapons:
            return np.random.choice(weapons[operator])
        else:
            return "Unknown Weapon"
    
    def get_match_info(self):
        """
        Retorna as informações da partida.
        
        Returns:
            dict: Informações da partida
        """
        return self.match_info
    
    def get_player_stats(self):
        """
        Retorna as estatísticas dos jogadores.
        
        Returns:
            list: Lista de estatísticas dos jogadores
        """
        return self.player_stats
    
    def get_round_stats(self):
        """
        Retorna as estatísticas das rodadas.
        
        Returns:
            list: Lista de estatísticas das rodadas
        """
        return self.round_stats
    
    def get_events(self):
        """
        Retorna os eventos do replay.
        
        Returns:
            list: Lista de eventos
        """
        return self.events
    
    def create_kill_dataframe(self):
        """
        Cria um DataFrame com os eventos de abate.
        
        Returns:
            pandas.DataFrame: DataFrame com eventos de abate
        """
        if not self.events:
            return pd.DataFrame()
        
        # Filtrar eventos de abate
        kill_events = [event for event in self.events if event["type"] == "kill"]
        
        # Converter para DataFrame
        return pd.DataFrame(kill_events)
    
    def create_round_dataframe(self):
        """
        Cria um DataFrame com as estatísticas das rodadas.
        
        Returns:
            pandas.DataFrame: DataFrame com estatísticas das rodadas
        """
        if not self.round_stats:
            return pd.DataFrame()
        
        # Converter para DataFrame
        return pd.DataFrame(self.round_stats)
    
    def save_match_summary(self, output_dir):
        """
        Salva um resumo da partida em formato JSON.
        
        Args:
            output_dir (str): Diretório de saída
            
        Returns:
            str: Caminho para o arquivo de resumo
        """
        if not self.match_info:
            return None
        
        # Criar diretório se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        # Criar resumo
        summary = {
            "match_info": self.match_info,
            "players": self.player_stats,
            "rounds": self.round_stats,
            "total_kills": len([e for e in self.events if e["type"] == "kill"]),
            "total_headshots": len([e for e in self.events if e["type"] == "kill" and e.get("headshot", False)]),
            "match_winner": "Attackers" if sum(1 for r in self.round_stats if r["winner"] == "Attackers") > sum(1 for r in self.round_stats if r["winner"] == "Defenders") else "Defenders"
        }
        
        # Salvar como JSON
        output_path = os.path.join(output_dir, "match_summary.json")
        with open(output_path, "w") as f:
            json.dump(summary, f, indent=2)
        
        return output_path
