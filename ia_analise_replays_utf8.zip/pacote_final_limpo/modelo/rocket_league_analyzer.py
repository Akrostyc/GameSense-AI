"""
Analisador para replays de Rocket League.
Este módulo implementa funções para analisar dados extraídos de replays do Rocket League.
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

class RocketLeagueAnalyzer:
    """
    Analisador para replays de Rocket League.
    
    Esta classe implementa métodos para analisar dados extraídos de replays do Rocket League
    e gerar insights sobre o desempenho dos jogadores.
    """
    
    def __init__(self):
        """
        Inicializa o analisador.
        """
        self.replay_data = None
        self.player_stats = None
        self.game_stats = None
        self.analysis_results = {}
    
    def load_data(self, replay_data):
        """
        Carrega os dados do replay para análise.
        
        Args:
            replay_data (dict): Dados extraídos do replay
        """
        self.replay_data = replay_data
    
    def load_dataframes(self, player_df, ball_df):
        """
        Carrega DataFrames de jogadores e bola para análise.
        
        Args:
            player_df (pandas.DataFrame): DataFrame com posições dos jogadores
            ball_df (pandas.DataFrame): DataFrame com posições da bola
        """
        self.player_df = player_df
        self.ball_df = ball_df
    
    def analyze_player_stats(self, player_stats):
        """
        Analisa as estatísticas dos jogadores.
        
        Args:
            player_stats (list): Lista de estatísticas dos jogadores
        """
        self.player_stats = player_stats
        
        # Calcular pontuações de habilidade
        blue_team = [p for p in player_stats if p["team"] == 0]
        orange_team = [p for p in player_stats if p["team"] == 1]
        
        # Calcular pontuações médias por time
        blue_score_avg = sum(p["score"] for p in blue_team) / len(blue_team) if blue_team else 0
        orange_score_avg = sum(p["score"] for p in orange_team) / len(orange_team) if orange_team else 0
        
        # Calcular estatísticas de gols
        blue_goals = sum(p["goals"] for p in blue_team)
        orange_goals = sum(p["goals"] for p in orange_team)
        
        # Calcular estatísticas de defesa
        blue_saves = sum(p["saves"] for p in blue_team)
        orange_saves = sum(p["saves"] for p in orange_team)
        
        # Armazenar resultados
        self.analysis_results["team_stats"] = {
            "blue": {
                "avg_score": blue_score_avg,
                "goals": blue_goals,
                "saves": blue_saves,
                "offensive_rating": self._calculate_offensive_rating(blue_team),
                "defensive_rating": self._calculate_defensive_rating(blue_team)
            },
            "orange": {
                "avg_score": orange_score_avg,
                "goals": orange_goals,
                "saves": orange_saves,
                "offensive_rating": self._calculate_offensive_rating(orange_team),
                "defensive_rating": self._calculate_defensive_rating(orange_team)
            }
        }
        
        # Analisar jogadores individualmente
        self.analysis_results["player_ratings"] = {}
        
        for player in player_stats:
            player_id = player["id"]
            
            # Calcular pontuações normalizadas (0-100)
            score_normalized = min(100, player["score"] / 10)
            goals_normalized = min(100, player["goals"] * 25)
            saves_normalized = min(100, player["saves"] * 25)
            assists_normalized = min(100, player["assists"] * 25)
            shots_normalized = min(100, player["shots"] * 10)
            
            # Calcular pontuação geral
            overall_rating = (
                score_normalized * 0.4 +
                goals_normalized * 0.2 +
                saves_normalized * 0.2 +
                assists_normalized * 0.1 +
                shots_normalized * 0.1
            )
            
            self.analysis_results["player_ratings"][player_id] = {
                "name": player["name"],
                "team": "blue" if player["team"] == 0 else "orange",
                "score_rating": score_normalized,
                "offensive_rating": (goals_normalized * 0.7 + shots_normalized * 0.3),
                "defensive_rating": (saves_normalized * 0.8 + assists_normalized * 0.2),
                "overall_rating": overall_rating
            }
    
    def analyze_game_stats(self, game_stats):
        """
        Analisa as estatísticas do jogo.
        
        Args:
            game_stats (dict): Estatísticas do jogo
        """
        self.game_stats = game_stats
        
        # Armazenar informações básicas
        self.analysis_results["game_info"] = {
            "map": game_stats.get("map", "Unknown"),
            "duration": game_stats.get("duration", 0),
            "date": game_stats.get("date", "Unknown"),
            "team_size": game_stats.get("team_size", 0),
            "blue_score": game_stats.get("blue_score", 0),
            "orange_score": game_stats.get("orange_score", 0),
            "winner": game_stats.get("winner", "tie")
        }
        
        # Calcular ritmo do jogo
        if "blue_score" in game_stats and "orange_score" in game_stats and "duration" in game_stats:
            total_goals = game_stats["blue_score"] + game_stats["orange_score"]
            minutes = game_stats["duration"] / 60
            
            if minutes > 0:
                goals_per_minute = total_goals / minutes
                self.analysis_results["game_pace"] = {
                    "goals_per_minute": goals_per_minute,
                    "pace_rating": min(100, goals_per_minute * 20)  # 5 gols/min = 100 rating
                }
    
    def analyze_positioning(self):
        """
        Analisa o posicionamento dos jogadores.
        
        Returns:
            dict: Resultados da análise de posicionamento
        """
        if not self.replay_data or "frames" not in self.replay_data:
            return {}
        
        # Analisar posicionamento dos jogadores em relação à bola
        frames = self.replay_data["frames"]
        players = self.replay_data["players"]
        
        # Inicializar métricas
        player_distances = {p["id"]: [] for p in players}
        team_spread = {0: [], 1: []}  # 0 = blue, 1 = orange
        
        # Calcular métricas para cada frame
        for frame in frames:
            ball_pos = np.array([frame["ball"]["x"], frame["ball"]["y"], frame["ball"]["z"]])
            
            # Posições dos jogadores por time
            blue_positions = []
            orange_positions = []
            
            for player in players:
                player_id = player["id"]
                team = player["team"]
                
                if player_id in frame["players"]:
                    player_pos = np.array([
                        frame["players"][player_id]["x"],
                        frame["players"][player_id]["y"],
                        frame["players"][player_id]["z"]
                    ])
                    
                    # Calcular distância à bola
                    distance = np.linalg.norm(player_pos - ball_pos)
                    player_distances[player_id].append(distance)
                    
                    # Adicionar posição à lista do time
                    if team == 0:
                        blue_positions.append(player_pos)
                    else:
                        orange_positions.append(player_pos)
            
            # Calcular espalhamento do time (distância média entre jogadores)
            if len(blue_positions) > 1:
                blue_spread = self._calculate_team_spread(blue_positions)
                team_spread[0].append(blue_spread)
            
            if len(orange_positions) > 1:
                orange_spread = self._calculate_team_spread(orange_positions)
                team_spread[1].append(orange_spread)
        
        # Calcular médias
        positioning_results = {
            "player_ball_distance": {},
            "team_spread": {
                "blue": np.mean(team_spread[0]) if team_spread[0] else 0,
                "orange": np.mean(team_spread[1]) if team_spread[1] else 0
            }
        }
        
        for player in players:
            player_id = player["id"]
            if player_distances[player_id]:
                avg_distance = np.mean(player_distances[player_id])
                positioning_results["player_ball_distance"][player_id] = avg_distance
        
        # Calcular pontuação de posicionamento
        blue_spread = positioning_results["team_spread"]["blue"]
        orange_spread = positioning_results["team_spread"]["orange"]
        
        # Pontuação baseada no espalhamento (nem muito junto, nem muito separado)
        # Valor ideal em torno de 2000-3000 unidades
        blue_spread_score = 100 - min(100, abs(blue_spread - 2500) / 25)
        orange_spread_score = 100 - min(100, abs(orange_spread - 2500) / 25)
        
        positioning_results["positioning_score"] = {
            "blue": blue_spread_score,
            "orange": orange_spread_score
        }
        
        # Armazenar resultados
        self.analysis_results["positioning"] = positioning_results
        
        # Calcular pontuação geral de posicionamento
        self.analysis_results["positioning_score"] = (blue_spread_score + orange_spread_score) / 2
        
        return positioning_results
    
    def analyze_boost_usage(self):
        """
        Analisa o uso de boost pelos jogadores.
        
        Returns:
            dict: Resultados da análise de boost
        """
        if not self.replay_data or "frames" not in self.replay_data:
            return {}
        
        # Analisar uso de boost
        frames = self.replay_data["frames"]
        players = self.replay_data["players"]
        
        # Inicializar métricas
        player_boost = {p["id"]: [] for p in players}
        
        # Calcular métricas para cada frame
        for frame in frames:
            for player in players:
                player_id = player["id"]
                
                if player_id in frame["players"] and "boost" in frame["players"][player_id]:
                    boost = frame["players"][player_id]["boost"]
                    player_boost[player_id].append(boost)
        
        # Calcular médias e estatísticas
        boost_results = {
            "player_avg_boost": {},
            "player_boost_efficiency": {}
        }
        
        for player in players:
            player_id = player["id"]
            if player_boost[player_id]:
                avg_boost = np.mean(player_boost[player_id])
                boost_results["player_avg_boost"][player_id] = avg_boost
                
                # Calcular eficiência (manter boost entre 30-70 é ideal)
                boost_values = np.array(player_boost[player_id])
                optimal_range = np.logical_and(boost_values >= 30, boost_values <= 70)
                efficiency = np.mean(optimal_range) * 100
                boost_results["player_boost_efficiency"][player_id] = efficiency
        
        # Calcular pontuação de boost por time
        blue_team = [p["id"] for p in players if p["team"] == 0]
        orange_team = [p["id"] for p in players if p["team"] == 1]
        
        blue_efficiency = np.mean([boost_results["player_boost_efficiency"].get(pid, 0) for pid in blue_team])
        orange_efficiency = np.mean([boost_results["player_boost_efficiency"].get(pid, 0) for pid in orange_team])
        
        boost_results["team_boost_efficiency"] = {
            "blue": blue_efficiency,
            "orange": orange_efficiency
        }
        
        # Armazenar resultados
        self.analysis_results["boost"] = boost_results
        
        # Calcular pontuação geral de boost
        self.analysis_results["boost_score"] = (blue_efficiency + orange_efficiency) / 2
        
        return boost_results
    
    def analyze_rotation(self):
        """
        Analisa a rotação dos jogadores.
        
        Returns:
            dict: Resultados da análise de rotação
        """
        if not self.replay_data or "frames" not in self.replay_data:
            return {}
        
        # Analisar rotação dos jogadores
        frames = self.replay_data["frames"]
        players = self.replay_data["players"]
        
        # Inicializar métricas
        player_positions = {p["id"]: [] for p in players}
        
        # Coletar posições ao longo do tempo
        for frame in frames:
            for player in players:
                player_id = player["id"]
                
                if player_id in frame["players"]:
                    pos = (
                        frame["players"][player_id]["x"],
                        frame["players"][player_id]["y"]
                    )
                    player_positions[player_id].append(pos)
        
        # Calcular métricas de rotação
        rotation_results = {
            "player_movement": {},
            "team_rotation": {}
        }
        
        for player in players:
            player_id = player["id"]
            positions = player_positions[player_id]
            
            if len(positions) > 1:
                # Calcular distância total percorrida
                total_distance = 0
                for i in range(1, len(positions)):
                    p1 = positions[i-1]
                    p2 = positions[i]
                    distance = np.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)
                    total_distance += distance
                
                # Calcular área coberta (aproximação usando convex hull)
                try:
                    from scipy.spatial import ConvexHull
                    if len(positions) >= 3:
                        hull = ConvexHull(positions)
                        area_covered = hull.volume
                    else:
                        area_covered = 0
                except:
                    # Fallback se scipy não estiver disponível
                    area_covered = 0
                
                rotation_results["player_movement"][player_id] = {
                    "total_distance": total_distance,
                    "area_covered": area_covered
                }
        
        # Calcular rotação por time
        blue_team = [p["id"] for p in players if p["team"] == 0]
        orange_team = [p["id"] for p in players if p["team"] == 1]
        
        # Calcular área coberta por time
        blue_positions = []
        orange_positions = []
        
        for player_id in blue_team:
            blue_positions.extend(player_positions[player_id])
        
        for player_id in orange_team:
            orange_positions.extend(player_positions[player_id])
        
        # Calcular área coberta usando convex hull
        blue_area = 0
        orange_area = 0
        
        try:
            from scipy.spatial import ConvexHull
            if len(blue_positions) >= 3:
                hull = ConvexHull(blue_positions)
                blue_area = hull.volume
            
            if len(orange_positions) >= 3:
                hull = ConvexHull(orange_positions)
                orange_area = hull.volume
        except:
            # Fallback se scipy não estiver disponível
            pass
        
        rotation_results["team_rotation"] = {
            "blue": {
                "area_covered": blue_area
            },
            "orange": {
                "area_covered": orange_area
            }
        }
        
        # Calcular pontuação de rotação
        # Área maior indica melhor cobertura do campo
        max_area = max(blue_area, orange_area) if max(blue_area, orange_area) > 0 else 1
        blue_rotation_score = min(100, (blue_area / max_area) * 100)
        orange_rotation_score = min(100, (orange_area / max_area) * 100)
        
        rotation_results["rotation_score"] = {
            "blue": blue_rotation_score,
            "orange": orange_rotation_score
        }
        
        # Armazenar resultados
        self.analysis_results["rotation"] = rotation_results
        
        # Calcular pontuação geral de rotação
        self.analysis_results["rotation_score"] = (blue_rotation_score + orange_rotation_score) / 2
        
        return rotation_results
    
    def get_analysis_results(self):
        """
        Retorna os resultados da análise.
        
        Returns:
            dict: Resultados da análise
        """
        return self.analysis_results
    
    def generate_recommendations(self):
        """
        Gera recomendações com base na análise.
        
        Returns:
            dict: Recomendações para melhorar o desempenho
        """
        recommendations = {
            "team": {
                "blue": [],
                "orange": []
            },
            "players": {}
        }
        
        # Verificar se temos resultados de análise
        if not self.analysis_results:
            return recommendations
        
        # Recomendações para times
        if "positioning" in self.analysis_results:
            positioning = self.analysis_results["positioning"]
            
            # Verificar espalhamento do time
            if "team_spread" in positioning:
                blue_spread = positioning["team_spread"].get("blue", 0)
                orange_spread = positioning["team_spread"].get("orange", 0)
                
                if blue_spread < 1500:
                    recommendations["team"]["blue"].append(
                        "Mantenha mais distância entre os jogadores para cobrir mais área do campo."
                    )
                elif blue_spread > 3500:
                    recommendations["team"]["blue"].append(
                        "Jogue mais próximo uns dos outros para facilitar passes e rotações."
                    )
                
                if orange_spread < 1500:
                    recommendations["team"]["orange"].append(
                        "Mantenha mais distância entre os jogadores para cobrir mais área do campo."
                    )
                elif orange_spread > 3500:
                    recommendations["team"]["orange"].append(
                        "Jogue mais próximo uns dos outros para facilitar passes e rotações."
                    )
        
        # Recomendações para boost
        if "boost" in self.analysis_results:
            boost = self.analysis_results["boost"]
            
            if "team_boost_efficiency" in boost:
                blue_efficiency = boost["team_boost_efficiency"].get("blue", 0)
                orange_efficiency = boost["team_boost_efficiency"].get("orange", 0)
                
                if blue_efficiency < 50:
                    recommendations["team"]["blue"].append(
                        "Melhore o gerenciamento de boost, evitando ficar com muito pouco ou desperdiçar quando está cheio."
                    )
                
                if orange_efficiency < 50:
                    recommendations["team"]["orange"].append(
                        "Melhore o gerenciamento de boost, evitando ficar com muito pouco ou desperdiçar quando está cheio."
                    )
        
        # Recomendações para rotação
        if "rotation" in self.analysis_results:
            rotation = self.analysis_results["rotation"]
            
            if "rotation_score" in rotation:
                blue_rotation = rotation["rotation_score"].get("blue", 0)
                orange_rotation = rotation["rotation_score"].get("orange", 0)
                
                if blue_rotation < 70:
                    recommendations["team"]["blue"].append(
                        "Melhore as rotações para cobrir mais área do campo e evitar aglomerações."
                    )
                
                if orange_rotation < 70:
                    recommendations["team"]["orange"].append(
                        "Melhore as rotações para cobrir mais área do campo e evitar aglomerações."
                    )
        
        # Recomendações para jogadores individuais
        if "player_ratings" in self.analysis_results:
            for player_id, ratings in self.analysis_results["player_ratings"].items():
                player_recommendations = []
                
                # Verificar pontuações
                offensive_rating = ratings.get("offensive_rating", 0)
                defensive_rating = ratings.get("defensive_rating", 0)
                
                if offensive_rating < 50:
                    player_recommendations.append(
                        "Melhore suas habilidades ofensivas, focando em chutes precisos e posicionamento para gols."
                    )
                
                if defensive_rating < 50:
                    player_recommendations.append(
                        "Trabalhe em suas defesas, posicionando-se melhor para interceptar chutes."
                    )
                
                # Adicionar recomendações específicas de boost se disponíveis
                if "boost" in self.analysis_results and "player_boost_efficiency" in self.analysis_results["boost"]:
                    boost_efficiency = self.analysis_results["boost"]["player_boost_efficiency"].get(player_id, 0)
                    
                    if boost_efficiency < 40:
                        player_recommendations.append(
                            "Melhore seu gerenciamento de boost, coletando pequenos pads e evitando ficar sem boost."
                        )
                
                # Adicionar recomendações se houver
                if player_recommendations:
                    recommendations["players"][player_id] = player_recommendations
        
        return recommendations
    
    def _calculate_offensive_rating(self, players):
        """
        Calcula a pontuação ofensiva de um time.
        
        Args:
            players (list): Lista de jogadores do time
            
        Returns:
            float: Pontuação ofensiva (0-100)
        """
        if not players:
            return 0
        
        # Calcular com base em gols e chutes
        total_goals = sum(p["goals"] for p in players)
        total_shots = sum(p["shots"] for p in players)
        
        # Normalizar para escala 0-100
        goals_score = min(100, total_goals * 25)
        shots_score = min(100, total_shots * 10)
        
        # Combinar (gols têm mais peso)
        return goals_score * 0.7 + shots_score * 0.3
    
    def _calculate_defensive_rating(self, players):
        """
        Calcula a pontuação defensiva de um time.
        
        Args:
            players (list): Lista de jogadores do time
            
        Returns:
            float: Pontuação defensiva (0-100)
        """
        if not players:
            return 0
        
        # Calcular com base em defesas
        total_saves = sum(p["saves"] for p in players)
        
        # Normalizar para escala 0-100
        return min(100, total_saves * 25)
    
    def _calculate_team_spread(self, positions):
        """
        Calcula o espalhamento de um time (distância média entre jogadores).
        
        Args:
            positions (list): Lista de posições dos jogadores
            
        Returns:
            float: Espalhamento médio
        """
        if len(positions) < 2:
            return 0
        
        # Calcular todas as distâncias par a par
        distances = []
        for i in range(len(positions)):
            for j in range(i+1, len(positions)):
                dist = np.linalg.norm(np.array(positions[i]) - np.array(positions[j]))
                distances.append(dist)
        
        # Retornar média
        return np.mean(distances)
    
    def save_analysis_results(self, output_dir):
        """
        Salva os resultados da análise em formato JSON.
        
        Args:
            output_dir (str): Diretório de saída
            
        Returns:
            str: Caminho para o arquivo de resultados
        """
        if not self.analysis_results:
            return None
        
        # Criar diretório se não existir
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar como JSON
        output_path = os.path.join(output_dir, "analysis_results.json")
        
        # Converter arrays numpy para listas
        results_json = self._convert_numpy_to_python(self.analysis_results)
        
        with open(output_path, "w") as f:
            json.dump(results_json, f, indent=2)
        
        return output_path
    
    def _convert_numpy_to_python(self, obj):
        """
        Converte arrays numpy para tipos Python nativos para serialização JSON.
        
        Args:
            obj: Objeto a ser convertido
            
        Returns:
            Objeto convertido
        """
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: self._convert_numpy_to_python(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_numpy_to_python(item) for item in obj]
        elif isinstance(obj, tuple):
            return tuple(self._convert_numpy_to_python(item) for item in obj)
        else:
            return obj
