"""
Interface web minimalista para upload de replays e visualização de resultados.
Este módulo implementa uma aplicação Flask para interação com o sistema de análise.
"""

import os
import json
from flask import Flask, request, render_template, redirect, url_for, flash, jsonify, send_from_directory
import sys
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Usar backend não-interativo
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Adicionar o diretório raiz ao path para importar módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from parser.rocket_league_parser import RocketLeagueParser, create_sample_replay

# Configuração da aplicação Flask
app = Flask(__name__)
app.secret_key = 'replay_analyzer_secret_key'

# Configuração de diretórios
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'data', 'uploads')
RESULTS_FOLDER = os.path.join(BASE_DIR, 'data', 'results')
STATIC_FOLDER = os.path.join(BASE_DIR, 'interface', 'static')

# Criar diretórios se não existirem
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)
os.makedirs(STATIC_FOLDER, exist_ok=True)
os.makedirs(os.path.join(STATIC_FOLDER, 'images'), exist_ok=True)

# Configurar a aplicação
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULTS_FOLDER'] = RESULTS_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Limite de 16MB para uploads

# Lista de extensões permitidas
ALLOWED_EXTENSIONS = {'replay'}

def allowed_file(filename):
    """
    Verifica se o arquivo tem uma extensão permitida.
    
    Args:
        filename (str): Nome do arquivo
        
    Returns:
        bool: True se a extensão for permitida, False caso contrário
    """
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """
    Rota principal da aplicação.
    
    Returns:
        str: Página HTML renderizada
    """
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """
    Rota para upload de arquivos de replay.
    
    Returns:
        Response: Redirecionamento para a página de resultados ou de erro
    """
    # Verificar se há arquivo na requisição
    if 'file' not in request.files:
        flash('Nenhum arquivo enviado')
        return redirect(request.url)
    
    file = request.files['file']
    
    # Verificar se o usuário selecionou um arquivo
    if file.filename == '':
        flash('Nenhum arquivo selecionado')
        return redirect(request.url)
    
    # Verificar se é um arquivo válido
    if file and allowed_file(file.filename):
        # Salvar o arquivo
        filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filename)
        
        # Processar o arquivo
        result_id = process_replay(filename)
        
        # Redirecionar para a página de resultados
        return redirect(url_for('show_results', result_id=result_id))
    else:
        flash('Tipo de arquivo não permitido. Apenas arquivos .replay são aceitos.')
        return redirect(request.url)

@app.route('/demo')
def use_demo():
    """
    Rota para usar um replay de demonstração.
    
    Returns:
        Response: Redirecionamento para a página de resultados
    """
    # Criar um replay de exemplo
    sample_replay = create_sample_replay(app.config['UPLOAD_FOLDER'])
    
    # Processar o replay
    result_id = process_replay(sample_replay)
    
    # Redirecionar para a página de resultados
    return redirect(url_for('show_results', result_id=result_id))

def process_replay(replay_path):
    """
    Processa um arquivo de replay e gera resultados.
    
    Args:
        replay_path (str): Caminho para o arquivo de replay
        
    Returns:
        str: ID dos resultados gerados
    """
    # Gerar um ID único para os resultados
    result_id = os.path.basename(replay_path).replace('.replay', '')
    
    # Criar diretório para os resultados
    result_dir = os.path.join(app.config['RESULTS_FOLDER'], result_id)
    os.makedirs(result_dir, exist_ok=True)
    
    # Analisar o replay
    parser = RocketLeagueParser(replay_path)
    if parser.parse():
        # Exportar dados para JSON
        parser.export_to_json(os.path.join(result_dir, 'replay_data.json'))
        
        # Gerar visualizações
        generate_visualizations(parser, result_dir, result_id)
    
    return result_id

def generate_visualizations(parser, result_dir, result_id):
    """
    Gera visualizações a partir dos dados do replay.
    
    Args:
        parser (RocketLeagueParser): Parser com dados do replay
        result_dir (str): Diretório para salvar as visualizações
        result_id (str): ID dos resultados
    """
    # Obter DataFrames
    player_df = parser.get_player_positions_dataframe()
    ball_df = parser.get_ball_positions_dataframe()
    
    # Gerar mapa de calor de posições
    plt.figure(figsize=(10, 8))
    plt.hexbin(player_df['x'], player_df['y'], gridsize=30, cmap='viridis')
    plt.colorbar(label='Densidade')
    plt.title('Mapa de Calor - Posições dos Jogadores')
    plt.xlabel('Coordenada X')
    plt.ylabel('Coordenada Y')
    plt.savefig(os.path.join(result_dir, 'heatmap.png'))
    plt.close()
    
    # Gerar gráfico de trajetória da bola
    plt.figure(figsize=(10, 8))
    plt.plot(ball_df['x'], ball_df['y'], 'r-', alpha=0.7)
    plt.scatter(ball_df['x'], ball_df['y'], c=ball_df['time'], cmap='plasma', s=10)
    plt.colorbar(label='Tempo (s)')
    plt.title('Trajetória da Bola')
    plt.xlabel('Coordenada X')
    plt.ylabel('Coordenada Y')
    plt.savefig(os.path.join(result_dir, 'ball_trajectory.png'))
    plt.close()
    
    # Gerar gráfico de uso de boost por jogador
    plt.figure(figsize=(12, 6))
    for player_id in player_df['player_id'].unique():
        player_data = player_df[player_df['player_id'] == player_id]
        plt.plot(player_data['time'], player_data['boost'], label=player_id)
    plt.title('Uso de Boost por Jogador')
    plt.xlabel('Tempo (s)')
    plt.ylabel('Boost')
    plt.legend()
    plt.savefig(os.path.join(result_dir, 'boost_usage.png'))
    plt.close()

@app.route('/results/<result_id>')
def show_results(result_id):
    """
    Rota para exibir os resultados da análise.
    
    Args:
        result_id (str): ID dos resultados
        
    Returns:
        str: Página HTML renderizada com os resultados
    """
    # Verificar se os resultados existem
    result_dir = os.path.join(app.config['RESULTS_FOLDER'], result_id)
    if not os.path.exists(result_dir):
        flash('Resultados não encontrados')
        return redirect(url_for('index'))
    
    # Carregar dados do replay
    replay_data_path = os.path.join(result_dir, 'replay_data.json')
    with open(replay_data_path, 'r') as f:
        replay_data = json.load(f)
    
    # Preparar dados para o template
    metadata = replay_data['metadata']
    players = replay_data['players']
    events = replay_data['events']
    
    # Caminhos para as visualizações
    visualizations = {
        'heatmap': url_for('static', filename=f'results/{result_id}/heatmap.png'),
        'ball_trajectory': url_for('static', filename=f'results/{result_id}/ball_trajectory.png'),
        'boost_usage': url_for('static', filename=f'results/{result_id}/boost_usage.png')
    }
    
    return render_template(
        'results.html',
        result_id=result_id,
        metadata=metadata,
        players=players,
        events=events,
        visualizations=visualizations
    )

@app.route('/static/results/<result_id>/<filename>')
def result_file(result_id, filename):
    """
    Rota para servir arquivos de resultados.
    
    Args:
        result_id (str): ID dos resultados
        filename (str): Nome do arquivo
        
    Returns:
        Response: Arquivo solicitado
    """
    return send_from_directory(os.path.join(app.config['RESULTS_FOLDER'], result_id), filename)

# Criar templates básicos
def create_templates():
    """
    Cria os templates HTML básicos para a aplicação.
    """
    templates_dir = os.path.join(BASE_DIR, 'interface', 'templates')
    os.makedirs(templates_dir, exist_ok=True)
    
    # Template base
    base_html = """<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Analisador de Replays{% endblock %}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
        }
        header {
            background-color: #2c3e50;
            color: white;
            padding: 1rem;
            text-align: center;
            margin-bottom: 2rem;
            border-radius: 5px;
        }
        h1, h2, h3 {
            color: #2c3e50;
        }
        .container {
            padding: 20px;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .btn {
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #2980b9;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="file"] {
            display: block;
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .visualization {
            margin-top: 20px;
            text-align: center;
        }
        .visualization img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <header>
        <h1>Analisador de Replays - Rocket League & Rainbow Six</h1>
    </header>
    
    <div class="container">
        {% with messages = get_flashed_messages() %}
            {% if messages %}
                {% for message in messages %}
                    <div class="alert alert-danger">{{ message }}</div>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>
</body>
</html>"""
    
    # Template da página inicial
    index_html = """{% extends "base.html" %}

{% block title %}Analisador de Replays - Upload{% endblock %}

{% block content %}
    <div class="card">
        <h2>Upload de Replay</h2>
        <p>Faça upload de um arquivo de replay do Rocket League para análise.</p>
        
        <form action="{{ url_for('upload_file') }}" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="file">Selecione um arquivo de replay (.replay):</label>
                <input type="file" name="file" id="file" accept=".replay">
            </div>
            
            <button type="submit" class="btn">Analisar Replay</button>
        </form>
    </div>
    
    <div class="card">
        <h2>Usar Replay de Demonstração</h2>
        <p>Não tem um replay? Use nosso replay de demonstração para testar o sistema.</p>
        
        <a href="{{ url_for('use_demo') }}" class="btn">Usar Demo</a>
    </div>
{% endblock %}"""
    
    # Template da página de resultados
    results_html = """{% extends "base.html" %}

{% block title %}Resultados da Análise{% endblock %}

{% block content %}
    <div class="card">
        <h2>Metadados da Partida</h2>
        <table>
            <tr>
                <th>Campo</th>
                <th>Valor</th>
            </tr>
            <tr>
                <td>ID</td>
                <td>{{ metadata.id }}</td>
            </tr>
            <tr>
                <td>Data</td>
                <td>{{ metadata.date }}</td>
            </tr>
            <tr>
                <td>Mapa</td>
                <td>{{ metadata.map_name }}</td>
            </tr>
            <tr>
                <td>Tipo de Partida</td>
                <td>{{ metadata.match_type }}</td>
            </tr>
            <tr>
                <td>Tamanho do Time</td>
                <td>{{ metadata.team_size }}</td>
            </tr>
            <tr>
                <td>Duração</td>
                <td>{{ metadata.duration }} segundos</td>
            </tr>
        </table>
    </div>
    
    <div class="card">
        <h2>Jogadores</h2>
        <table>
            <tr>
                <th>Nome</th>
                <th>Time</th>
                <th>ID do Carro</th>
            </tr>
            {% for player in players %}
            <tr>
                <td>{{ player.name }}</td>
                <td>{{ player.team }}</td>
                <td>{{ player.car_id }}</td>
            </tr>
            {% endfor %}
        </table>
    </div>
    
    <div class="card">
        <h2>Eventos</h2>
        <table>
            <tr>
                <th>Tipo</th>
                <th>Tempo</th>
                <th>Detalhes</th>
            </tr>
            {% for event in events %}
            <tr>
                <td>{{ event.type }}</td>
                <td>{{ event.time }} segundos</td>
                <td>
                    {% if event.type == 'goal' %}
                        Gol de {{ event.player }} (Time {{ event.team }})
                    {% elif event.type == 'demo' %}
                        {{ event.attacker }} demoliu {{ event.victim }}
                    {% else %}
                        -
                    {% endif %}
                </td>
            </tr>
            {% endfor %}
        </table>
    </div>
    
    <div class="card">
        <h2>Visualizações</h2>
        
        <div class="visualization">
            <h3>Mapa de Calor - Posições dos Jogadores</h3>
            <img src="{{ visualizations.heatmap }}" alt="Mapa de Calor">
            <p>Este mapa de calor mostra onde os jogadores passaram mais tempo durante a partida.</p>
        </div>
        
        <div class="visualization">
            <h3>Trajetória da Bola</h3>
            <img src="{{ visualizations.ball_trajectory }}" alt="Trajetória da Bola">
            <p>Este gráfico mostra o movimento da bola ao longo da partida. A cor indica o tempo.</p>
        </div>
        
        <div class="visualization">
            <h3>Uso de Boost por Jogador</h3>
            <img src="{{ visualizations.boost_usage }}" alt="Uso de Boost">
            <p>Este gráfico mostra o nível de boost de cada jogador ao longo do tempo.</p>
        </div>
    </div>
    
    <div class="card">
        <h2>Análise</h2>
        
        <h3>Posicionamento</h3>
        <p>Com base no mapa de calor, observamos que os jogadores tendem a se concentrar nas áreas laterais do campo, 
        com menos presença na área central. Isso pode indicar um estilo de jogo que favorece ataques pelos flancos.</p>
        
        <h3>Controle de Bola</h3>
        <p>A trajetória da bola mostra um padrão circular, sugerindo que a posse de bola alternava frequentemente entre as equipes.
        Isso pode indicar um jogo equilibrado com transições rápidas.</p>
        
        <h3>Gerenciamento de Boost</h3>
        <p>O gráfico de boost mostra que os jogadores mantiveram níveis relativamente altos durante a partida, 
        com quedas periódicas que provavelmente correspondem a momentos de uso intensivo para alcançar a bola ou defender.</p>
        
        <h3>Eventos Importantes</h3>
        <p>A partida teve um total de {{ events|selectattr('type', 'equalto', 'goal')|list|length }} gols e 
        {{ events|selectattr('type', 'equalto', 'demo')|list|length }} demolições, indicando um jogo com bom equilíbrio 
        entre ofensiva e agressividade.</p>
    </div>
    
    <a href="{{ url_for('index') }}" class="btn">Voltar</a>
{% endblock %}"""
    
    # Salvar templates
    with open(os.path.join(templates_dir, 'base.html'), 'w') as f:
        f.write(base_html)
    
    with open(os.path.join(templates_dir, 'index.html'), 'w') as f:
        f.write(index_html)
    
    with open(os.path.join(templates_dir, 'results.html'), 'w') as f:
        f.write(results_html)

# Criar templates ao importar o módulo
create_templates()

if __name__ == '__main__':
    # Criar diretório para templates se não existir
    templates_dir = os.path.join(BASE_DIR, 'interface', 'templates')
    os.makedirs(templates_dir, exist_ok=True)
    
    # Iniciar a aplicação
    app.run(debug=True, host='0.0.0.0', port=5000)
